from datetime import datetime
from config import TIMEZONE
def local_now():
    return datetime.now(TIMEZONE)
