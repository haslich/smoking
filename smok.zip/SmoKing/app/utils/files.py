from pathlib import Path
from PIL import Image, UnidentifiedImageError
def image_extension(path):
    try:
        with Image.open(path) as im:
            kind=im.format
            im.verify()
        return {'JPEG':'.jpg','PNG':'.png','WEBP':'.webp'}.get(kind)
    except (OSError,ValueError,UnidentifiedImageError):
        return None
