"""Admin keyboards currently live in app.handlers.legacy for compatibility."""
