"""Keyboard definitions currently live in app.handlers.legacy for compatibility."""
