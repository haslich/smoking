from app.database import store
def pending_notifications():
    return store.all('SELECT * FROM outbox WHERE delivered IS NULL ORDER BY id')
