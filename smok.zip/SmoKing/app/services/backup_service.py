from pathlib import Path
from config import ROOT
def backup_directory()->Path:
    p=ROOT/'backups'
    p.mkdir(parents=True,exist_ok=True)
    return p
