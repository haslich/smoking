from datetime import date, timedelta
def last_completed_period(today:date):
    if today.day >= 15:
        return today.replace(day=1),today.replace(day=14)
    previous=today.replace(day=1)-timedelta(days=1)
    return previous.replace(day=16),previous
