from app.database import store
def pending_lists():
    return store.all("SELECT * FROM records WHERE kind='list' AND status='pending' ORDER BY id")
