from app.database import store
def pending_reports():
    return store.all("SELECT * FROM records WHERE kind='report' AND status='pending' ORDER BY id")
