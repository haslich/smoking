from config import STORE_CLOSING_HOURS, PAY_PER_SHIFT
def closing_hour(shop):
    return STORE_CLOSING_HOURS[shop]
def shift_pay():
    return PAY_PER_SHIFT
