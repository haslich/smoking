"""Handler extraction point. Active handlers are registered in legacy.py."""
