"""Admin handler extraction point. Active handlers are in ../legacy.py."""
