import asyncio, os, html, logging, uuid, calendar, mimetypes, shutil, zipfile, sqlite3, json, tempfile, hashlib
from logging.handlers import RotatingFileHandler
from pathlib import Path
from contextlib import suppress, closing
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, Router, F
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.base import BaseStorage, StorageKey, StateType
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.events import EVENT_JOB_ERROR
from PIL import Image, UnidentifiedImageError
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from app.database import store
from config import TIMEZONE, PAY_PER_SHIFT, STORE_CLOSING_HOURS, PAYROLL_EXPORT_DIR

load_dotenv(); TOKEN=os.getenv('BOT_TOKEN',''); ADMINS={int(s.strip()) for s in os.getenv('ADMIN_IDS','').split(',') if s.strip().isdigit()}
TZ=TIMEZONE; SHOPS=list(STORE_CLOSING_HOURS); PAY=PAY_PER_SHIFT
ROOT=Path(__file__).resolve().parents[2]; router=Router(); bot=None
MAX_STORAGE_BYTES=int(os.getenv('MAX_STORAGE_GB','10'))*1024**3
# Serialize file writes and backups in this bot process. Other processes must not write to storage.
STORAGE_LOCK=asyncio.Lock()
OUTBOX_DELIVERY_LOCK=asyncio.Lock()
OUTBOX_WAKEUP=asyncio.Event()
LOCK_FILE=None

def wake_outbox():
    """Wake the durable notification worker after a successful DB commit."""
    OUTBOX_WAKEUP.set()
class SQLiteFSMStorage(BaseStorage):
    def _key(self,key):return f'{key.bot_id}:{key.chat_id}:{key.user_id}:{key.thread_id or 0}:{key.destiny}'
    async def set_state(self,key:StorageKey,state:StateType=None):
        store.update_fsm_field(self._key(key),'state',state.state if isinstance(state,State) else state,stamp())
    async def get_state(self,key:StorageKey):
        row=store.one('SELECT value FROM fsm WHERE key=?',(self._key(key),));return json.loads(row['value'])['state'] if row else None
    async def set_data(self,key:StorageKey,data:dict):
        store.update_fsm_field(self._key(key),'data',data.copy(),stamp())
    async def get_data(self,key:StorageKey):
        row=store.one('SELECT value FROM fsm WHERE key=?',(self._key(key),));return json.loads(row['value']).get('data',{}).copy() if row else {}
    async def close(self):pass

def safe_path(path):
    p=Path(path).resolve();root=(ROOT/'storage').resolve()
    if not p.is_relative_to(root):raise ValueError('File outside storage')
    return p

def storage_usage():
    base=ROOT/'storage'
    return sum(p.stat().st_size for p in base.rglob('*') if p.is_file()) if base.exists() else 0

def has_storage_capacity(incoming_size=0):
    return storage_usage()+incoming_size<=MAX_STORAGE_BYTES

def detect_image(path):
    try:
        with Image.open(path) as img:
            fmt=img.format
            img.verify()
        return {'JPEG':'.jpg','PNG':'.png','WEBP':'.webp'}.get(fmt)
    except (UnidentifiedImageError,OSError,ValueError):return None


def now():return datetime.now(TZ)
def stamp():return now().isoformat(timespec='seconds')
def esc(s):return html.escape(str(s),quote=False)
def btn(label,callback):return InlineKeyboardButton(text=label,callback_data=callback)
def keyboard(*rows):return InlineKeyboardMarkup(inline_keyboard=[list(r) for r in rows])
def back(target='home'):return [btn('⬅️ Назад',target)]
def allowed(uid):return bool(store.one("SELECT 1 FROM users WHERE id=? AND status='approved'",(uid,)))
def admin(uid):return uid in ADMINS
def manager(uid):return bool(store.manager_shop_names(uid))
def staff(uid):return admin(uid) or manager(uid)
def can_manage(uid,shop):return admin(uid) or shop in store.manager_shop_names(uid)
def shops_now():return store.active_shops()
def shop_names():return [x['name'] for x in shops_now()]
def recipients_for(shop):return store.notification_recipients(shop,ADMINS)
def current(uid):return store.one("SELECT * FROM shifts WHERE user_id=? AND status='open'",(uid,))
def user(uid):return store.one('SELECT * FROM users WHERE id=?',(uid,))

def eligible_record(uid,rid,kind):
    return store.one("SELECT * FROM records WHERE id=? AND user_id=? AND kind=? AND status='revision'",(rid,uid,kind))

class S(StatesGroup):
    registration=State(); photo=State(); comment=State(); list_text=State(); rename=State(); revision=State(); announcement=State(); announcement_confirm=State(); correction_photo=State(); correction_list=State(); shop_edit=State()

async def reply(c,text,markup=None):
    try:
        if c.message.content_type=='text':await c.message.edit_text(text,reply_markup=markup)
        else:await c.message.answer(text,reply_markup=markup)
    except Exception as exc:
        if 'message is not modified' not in str(exc).lower():
            logging.warning('Cannot edit Telegram message: %s',exc)
            await c.message.answer(text,reply_markup=markup)
    # Telegram rejects acknowledgements for callbacks that spent too long in
    # the update backlog during an outage. The requested screen was already
    # rendered, so this specific acknowledgement failure is harmless.
    with suppress(TelegramBadRequest):await c.answer()

async def notify(uid,text,document=None,photo=None,markup=None):
    try:
        if photo:await bot.send_photo(uid,photo,caption=html.escape(html.unescape(text)[:850],quote=False),reply_markup=markup)
        else:await bot.send_message(uid,text,reply_markup=markup)
        if document:await bot.send_document(uid,FSInputFile(document))
        return True
    except Exception:
        logging.exception('Notification failed to %s',uid)
        try:store.audit(uid,'notification_failed',text[:120])
        except Exception:pass
        return False

async def notify_admins(text,**kwargs):
    for uid in ADMINS:await notify(uid,text,**kwargs)

def home_k(uid):
    rows=[[btn('💰 Зарплата','salary')],[btn('🔴 Закрыть смену' if current(uid) else '🟢 Открыть смену','close' if current(uid) else 'open')],[btn('📋 Отправить список','list')],[btn('👤 Профиль','profile')]]
    if admin(uid):rows.append([btn('⚙️ Админ-панель','admin')])
    elif manager(uid):rows.append([btn('🏪 Панель управляющего','managerpanel')])
    return keyboard(*rows)

@router.message(CommandStart())
async def start(m:Message,state:FSMContext):
    await state.clear();u=user(m.from_user.id)
    if not u:
        await state.set_state(S.registration);return await m.answer('🏪 <b>SmoKing</b>\n\nВведите полное ФИО одним сообщением.')
    if u['status']=='rejected':
        await state.set_state(S.registration)
        return await m.answer('Заявка была отклонена. Для повторной подачи введите ФИО.')
    if u['status']=='archived':return await m.answer('Ваш доступ к SmoKing отключён администратором. Обратитесь к руководителю.')
    if u['status']!='approved':return await m.answer('Ваша заявка ожидает подтверждения.')
    stale=current(m.from_user.id)
    warning=''
    if stale and stale['day']<now().date().isoformat():
        warning=f'\n\n⚠️ У вас не закрыта смена за {esc(stale["day"])} в магазине {esc(stale["shop"])}. Закройте её фотоотчётом.'
    await m.answer('🏪 <b>SmoKing</b>\n\nДобро пожаловать, '+esc(u['name'])+'!'+warning,reply_markup=home_k(m.from_user.id))

@router.message(Command('cancel'))
async def cancel(m:Message,state:FSMContext):
    data=await state.get_data()
    if data.get('path'):
        with suppress(OSError,ValueError):safe_path(data['path']).unlink(missing_ok=True)
    await state.clear();await m.answer('Действие отменено. /start')

@router.message(S.registration,F.text)
async def register(m:Message,state:FSMContext):
    name=' '.join(m.text.split())
    if not 2<=len(name.split())<=4 or len(name)>120:return await m.answer('Укажите фамилию, имя и при наличии отчество (до 120 символов).')
    created=store.submit_registration(m.from_user.id,name,m.from_user.username or '',ADMINS,stamp())
    if not created:
        await state.clear();return await m.answer('Заявка уже находится на рассмотрении или одобрена.')
    wake_outbox()
    await state.clear()
    await m.answer('🟡 Заявка отправлена администратору.')

@router.callback_query(F.data.startswith(('approve:','reject:')))
async def approval(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    action,raw=c.data.split(':');uid=int(raw);u=user(uid)
    if not u:return await c.answer('Заявка не найдена',show_alert=True)
    if u['status']!='pending':return await c.answer('Заявка уже рассмотрена',show_alert=True)
    status='approved' if action=='approve' else 'rejected'
    changed=store.decide_registration(uid,c.from_user.id,status,stamp())
    if not changed:return await c.answer('Заявка уже рассмотрена',show_alert=True)
    wake_outbox()
    await reply(c,'Заявка '+('одобрена' if status=='approved' else 'отклонена')+': '+esc(u['name']))

@router.callback_query(F.data=='home')
async def home(c:CallbackQuery,state:FSMContext):
    await state.clear();u=user(c.from_user.id)
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    await reply(c,'🏪 <b>SmoKing</b>\n\n'+esc(u['name']),home_k(c.from_user.id))

@router.callback_query(F.data=='open')
async def open_menu(c:CallbackQuery):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    if current(c.from_user.id):return await c.answer('Смена уже открыта',show_alert=True)
    names=shop_names();rows=[[btn('🏪 '+name,f'openstore:{i}')] for i,name in enumerate(names)];rows.append(back())
    await reply(c,'Выберите магазин для открытия смены:',keyboard(*rows))

@router.callback_query(F.data.startswith('openstore:'))
async def open_store(c:CallbackQuery):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:
        idx=int(c.data.split(':')[1])
        names=shop_names()
        if not 0<=idx<len(names):raise ValueError('Invalid shop')
        shop=names[idx]
    except (ValueError,IndexError):return await c.answer('Неизвестный магазин',show_alert=True)
    settings=store.shop(shop)
    unusual=now().hour<settings['opening_hour'] or now().hour>=settings['closing_hour']
    ok=store.open_shift(c.from_user.id,shop,now().date().isoformat(),stamp(),recipients_for(shop))
    if not ok:return await c.answer('Вы уже открывали смену сегодня или есть открытая смена',show_alert=True)
    wake_outbox()
    store.audit(c.from_user.id,'shift_open',shop)
    warning=(f'\n\n⚠️ Необычное время открытия. Рабочее время магазина: {settings["opening_hour"]:02d}:00–{settings["closing_hour"]:02d}:00.' if unusual else '')
    if unusual:
        store.queue_many(recipients_for(shop),f'⚠️ Необычное время открытия смены: сотрудник ID {c.from_user.id}, магазин {shop}, время {now().strftime("%H:%M")}.')
        wake_outbox()
    await reply(c,'🟢 Смена открыта\n🏪 '+esc(shop)+warning,home_k(c.from_user.id))

@router.callback_query(F.data=='close')
async def close(c:CallbackQuery,state:FSMContext):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    s=current(c.from_user.id)
    if not s:return await c.answer('Нет открытой смены',show_alert=True)
    await state.update_data(shift_id=s['id']);await state.set_state(S.photo)
    await reply(c,'📸 Отправьте фотографию отчёта для закрытия смены.\nДля отмены: /cancel')

def incoming_image(m:Message):
    if m.photo and (m.photo[-1].file_size or 0)<=20*1024*1024:return m.photo[-1],'.jpg'
    d=m.document
    if d and d.mime_type in ('image/jpeg','image/png','image/webp') and d.file_size and d.file_size<=20*1024*1024:
        return d,{'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp'}[d.mime_type]
    return None,None

@router.message(S.photo,F.photo | F.document)
async def photo(m:Message,state:FSMContext):
    s=current(m.from_user.id);d=await state.get_data()
    if not allowed(m.from_user.id):
        await state.clear();return await m.answer('Доступ отозван. Обратитесь к администратору.')
    if not s or s['id']!=d.get('shift_id'):
        await state.clear();return await m.answer('Смена не найдена. /start')
    media,ext=incoming_image(m)
    if not media:return await m.answer('Отправьте фото или изображение JPG, PNG, WEBP как файл (до 20 МБ).')
    folder=ROOT/'storage'/'reports'/s['shop'];folder.mkdir(parents=True,exist_ok=True)
    path=folder/f"{s['shop']}_{m.from_user.id}_{now().strftime('%Y-%m-%d_%H-%M-%S')}_{uuid.uuid4().hex[:8]}{ext}"
    async with STORAGE_LOCK:
        if not has_storage_capacity(getattr(media,'file_size',0) or 0):
            return await m.answer('Хранилище заполнено. Сообщите администратору.')
        try:
            await asyncio.wait_for(bot.download(media,destination=path),timeout=90)
            detected=detect_image(path)
            if not detected:raise ValueError('Invalid image')
            if detected!=ext:
                actual=path.with_suffix(detected);path.rename(actual);path=actual
        except Exception:
            path.unlink(missing_ok=True)
            logging.exception('Image download or validation failed')
            return await m.answer('Не удалось проверить изображение. Отправьте JPG, PNG или WEBP ещё раз.')
    previous=(await state.get_data()).get('path')
    if previous and previous!=str(path):
        with suppress(OSError,ValueError):safe_path(previous).unlink(missing_ok=True)
    await state.update_data(path=str(path),file_id=media.file_id)
    await state.set_state(S.comment)
    await m.answer('💬 Напишите комментарий или нажмите «Пропустить».',reply_markup=keyboard([btn('⏭ Пропустить','skipcomment')],[btn('❌ Отмена','cancelclose')]))

@router.callback_query(F.data.in_({'skipcomment','cancelclose'}))
async def comment_buttons(c:CallbackQuery,state:FSMContext):
    if c.data=='cancelclose':
        d=await state.get_data()
        if d.get('path'):
            with suppress(ValueError,OSError):safe_path(d['path']).unlink(missing_ok=True)
        await state.clear()
        return await reply(c,'Закрытие отменено.',keyboard(back()))
    if await state.get_state()!=S.comment.state:return await c.answer('Действие уже завершено',show_alert=True)
    ok=await finish_close(c.from_user.id,'',state)
    await reply(c,'Готово. Отчёт отправлен.' if ok else 'Не удалось закрыть смену. Попробуйте /start.',home_k(c.from_user.id))

@router.message(S.comment,F.text)
async def comment(m:Message,state:FSMContext):
    ok=await finish_close(m.from_user.id,m.text[:2000],state)
    await m.answer('✅ Отчёт отправлен, смена закрыта. Начислено 2300 ₽.' if ok else '⚠️ Смена уже закрыта или не найдена.',reply_markup=home_k(m.from_user.id))

async def finish_close(uid,comment,state):
    if not allowed(uid):await state.clear();return False
    d=await state.get_data();s=current(uid)
    if not s or s['id']!=d.get('shift_id') or not d.get('path') or not safe_path(d['path']).is_file():await state.clear();return False
    try:rid=store.close_shift(uid,s['shop'],s['id'],d['path'],d['file_id'],comment,stamp(),recipients_for(s['shop']))
    except Exception:
        logging.exception('Cannot close shift')
        return False
    await state.clear()
    if not rid:
        with suppress(OSError,ValueError):safe_path(d['path']).unlink(missing_ok=True)
    if rid:
        store.audit(uid,'shift_close',str(s['id']))
        wake_outbox()
    return bool(rid)

@router.callback_query(F.data=='list')
async def list_menu(c:CallbackQuery,state:FSMContext):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    await state.clear();await reply(c,'Выберите тип списка:',keyboard([btn('📋 Обычный','listtype:Обычный')],[btn('➕ Доп','listtype:Доп')],back()))

@router.callback_query(F.data.startswith('listtype:'))
async def list_type(c:CallbackQuery,state:FSMContext):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    typ=c.data.split(':',1)[1]
    if typ not in ('Обычный','Доп'):return await c.answer('Неверный тип',show_alert=True)
    await state.clear();await state.update_data(category=typ)
    s=current(c.from_user.id)
    if s:
        await state.update_data(shop=s['shop']);await state.set_state(S.list_text)
        return await reply(c,'Введите текст списка. Магазин: '+esc(s['shop'])+'\nОтмена: /cancel')
    names=shop_names();rows=[[btn('🏪 '+name,f'listshop:{i}')] for i,name in enumerate(names)];rows.append(back('list'))
    await reply(c,'Выберите магазин:',keyboard(*rows))

@router.callback_query(F.data.startswith('listshop:'))
async def list_shop(c:CallbackQuery,state:FSMContext):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    d=await state.get_data()
    if d.get('category') not in ('Обычный','Доп'):return await c.answer('Сначала выберите тип',show_alert=True)
    try:
        index=int(c.data.split(':')[1])
        names=shop_names()
        if index<0 or index>=len(names):raise ValueError('Out of range')
        shop=names[index]
    except (ValueError,IndexError):return await c.answer('Неверный магазин',show_alert=True)
    await state.update_data(shop=shop);await state.set_state(S.list_text)
    await reply(c,'Отправьте список текстом. Магазин: '+esc(shop)+'\nОтмена: /cancel')

@router.message(S.list_text,F.text)
async def list_save(m:Message,state:FSMContext):
    if not allowed(m.from_user.id):await state.clear();return await m.answer('Нет доступа')
    d=await state.get_data();shop=d['shop'];typ=d['category'];u=user(m.from_user.id)
    if len(m.text)>30000:return await m.answer('Слишком длинный список (максимум 30 000 символов).')
    folder=ROOT/'storage'/'lists'/shop;folder.mkdir(parents=True,exist_ok=True)
    path=folder/f"{typ}_{shop}_{m.from_user.id}_{now().strftime('%Y-%m-%d_%H-%M-%S')}_{uuid.uuid4().hex[:8]}.txt"
    payload=f'Магазин: {shop}\nСотрудник: {u["name"]}\nТип: {typ}\nДата: {stamp()}\n\n{m.text}'
    async with STORAGE_LOCK:
        if not has_storage_capacity(len(payload.encode('utf-8'))):
            return await m.answer('Хранилище заполнено. Сообщите администратору.')
        try:
            path.write_text(payload,encoding='utf-8')
            targets=recipients_for(shop)|{x['id'] for x in store.all("SELECT id FROM users WHERE list_access=1 AND status='approved'")}
            rid=store.submit_list(m.from_user.id,shop,typ,str(path),m.text,stamp(),targets,m.chat.id,m.message_id)
            existing=store.one('SELECT path FROM records WHERE id=?',(rid,))
            if existing and existing['path']!=str(path):path.unlink(missing_ok=True)
        except Exception:
            path.unlink(missing_ok=True)
            logging.exception('Cannot save list')
            return await m.answer('Ошибка сохранения списка. Попробуйте ещё раз.')
    await state.clear();store.audit(m.from_user.id,'list_submit',str(rid))
    wake_outbox()
    await m.answer('✅ Список сохранён и поставлен в очередь отправки.',reply_markup=home_k(m.from_user.id))

@router.callback_query(F.data=='salary')
async def salary(c:CallbackQuery):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    start=now().date().replace(day=1).isoformat();end=(now().date().replace(day=28)+timedelta(days=4)).replace(day=1).isoformat()
    x=store.one("SELECT COUNT(*) n,COALESCE(SUM(pay),0) total FROM shifts WHERE user_id=? AND status='closed' AND day>=? AND day<?",(c.from_user.id,start,end))
    recent=store.all("SELECT shop,day FROM shifts WHERE user_id=? AND status='closed' ORDER BY day DESC LIMIT 5",(c.from_user.id,))
    lines='\n'.join(f'• {esc(s["day"])} — {esc(s["shop"])}' for s in recent) or 'Пока нет смен'
    await reply(c,f'💰 Зарплата за {now().strftime("%m.%Y")}\nСмен: {x["n"]}\nНачислено: {x["total"]} ₽\n\nПоследние смены:\n{lines}',keyboard([btn('📊 История зарплаты','history:0')],back()))

@router.callback_query(F.data.startswith('history:'))
async def history(c:CallbackQuery):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:p=max(0,int(c.data.split(':')[1]))
    except (ValueError,IndexError):return await c.answer('Некорректная страница',show_alert=True)
    items=store.all("SELECT substr(day,1,7) period,COUNT(*) n,SUM(pay) total FROM shifts WHERE user_id=? AND status='closed' GROUP BY period ORDER BY period DESC",(c.from_user.id,))
    if not items:return await reply(c,'История зарплаты пока пуста.',keyboard(back('salary')))
    p=min(p,len(items)-1);x=items[p];nav=[]
    if p:nav.append(btn('◀️',f'history:{p-1}'))
    nav.append(btn(f'{p+1}/{len(items)}','noop'))
    if p+1<len(items):nav.append(btn('▶️',f'history:{p+1}'))
    await reply(c,f'📊 {x["period"]}\nСмен: {x["n"]}\nНачислено: {x["total"]} ₽',keyboard(nav,back('salary')))

@router.callback_query(F.data=='profile')
async def profile(c:CallbackQuery):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    month=now().strftime('%Y-%m')
    await reply(c,'👤 Профиль\nФИО: '+esc(user(c.from_user.id)['name']),keyboard([btn('📅 Календарь смен',f'calendar:{c.from_user.id}:{month}')],[btn('✏️ Изменить ФИО','rename')],back()))
@router.callback_query(F.data=='rename')
async def rename(c:CallbackQuery,state:FSMContext):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    await state.set_state(S.rename);await reply(c,'Введите новое ФИО. /cancel')
@router.message(S.rename,F.text)
async def rename_save(m:Message,state:FSMContext):
    if not allowed(m.from_user.id):await state.clear();return await m.answer('Нет доступа')
    name=' '.join(m.text.split())
    if not 2<=len(name.split())<=4 or len(name)>120:return await m.answer('Введите корректное ФИО.')
    store.run('UPDATE users SET name=? WHERE id=?',(name,m.from_user.id));store.audit(m.from_user.id,'rename',name)
    await state.clear();await m.answer('ФИО обновлено.',reply_markup=home_k(m.from_user.id))

@router.callback_query(F.data=='admin')
async def admin_menu(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    rows=[[btn(t,k)] for t,k in [('🟢 Сейчас работают','working'),('👥 Сотрудники','employees:0'),('🗄 Архив сотрудников','archive:0'),('🏪 Магазины','shops'),('📸 Отчёты','records:report:0'),('📋 Списки','records:list:0'),('💰 Зарплатные отчёты','paymenu'),('📢 Объявление','announce'),('🔐 Доступ','access:0')]]
    rows.append(back());await reply(c,'⚙️ Админ-панель SmoKing',keyboard(*rows))

@router.callback_query(F.data=='managerpanel')
async def manager_panel(c:CallbackQuery):
    managed=store.manager_shop_names(c.from_user.id)
    if not managed:return await c.answer('Нет доступа',show_alert=True)
    await reply(c,'🏪 Панель управляющего\n\nМагазины: '+', '.join(map(esc,managed)),keyboard([btn('🟢 Открытые смены','managerworking')],[btn('📸 Отчёты на проверке','managerreports:0')],back()))

@router.callback_query(F.data=='managerworking')
async def manager_working(c:CallbackQuery):
    managed=store.manager_shop_names(c.from_user.id)
    if not managed:return await c.answer('Нет доступа',show_alert=True)
    placeholders=','.join('?' for _ in managed)
    rows=store.all(f"SELECT s.shop,s.opened,u.name FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.status='open' AND s.shop IN ({placeholders}) ORDER BY s.shop",managed)
    text='\n'.join(f'🏪 {esc(x["shop"])} — {esc(x["name"])} ({esc(x["opened"][11:16])})' for x in rows) or 'Открытых смен нет.'
    await reply(c,'🟢 Открытые смены\n\n'+text,keyboard(back('managerpanel')))

@router.callback_query(F.data.startswith('managerreports:'))
async def manager_reports(c:CallbackQuery):
    managed=store.manager_shop_names(c.from_user.id)
    if not managed:return await c.answer('Нет доступа',show_alert=True)
    try:p=int(c.data.split(':')[1])
    except (ValueError,IndexError):p=0
    placeholders=','.join('?' for _ in managed)
    items=store.all(f"SELECT r.*,u.name FROM records r JOIN users u ON u.id=r.user_id WHERE r.kind='report' AND r.shop IN ({placeholders}) ORDER BY r.id DESC",managed)
    await show_page(c,items,p,'📸 Отчёты моих магазинов','managerreports','managerpanel',lambda x:f'№{x["id"]} — {esc(x["name"])}\n🏪 {esc(x["shop"])}\nСтатус: {esc(x["status"])}')

@router.callback_query(F.data=='working')
@router.callback_query(F.data.startswith('working:'))
async def working(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    items=store.all("SELECT s.id,s.shop,u.name,s.opened FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.status='open' ORDER BY s.shop")
    lines='\n'.join(f'🏪 {esc(x["shop"])} — {esc(x["name"])} ({esc(x["opened"][11:16])})' for x in items) or 'Никто не работает.'
    page=int(c.data.split(':')[1]) if ':' in c.data else 0
    page=max(0,min(page,max(0,(len(items)-1)//20)))
    shown=items[page*20:(page+1)*20]
    text='\n'.join(f'🏪 {esc(x["shop"])} — {esc(x["name"])} ({esc(x["opened"][11:16])})' for x in shown) or 'Никто не работает.'
    nav=[]
    if page:nav.append(btn('◀️',f'working:{page-1}'))
    if (page+1)*20<len(items):nav.append(btn('▶️',f'working:{page+1}'))
    action_rows=[[btn('✏️ '+x['name'][:24],f'changeshop:{x["id"]}')] for x in shown]
    await reply(c,'🟢 Открытые смены\n\n'+text,keyboard(*action_rows,*( [nav] if nav else []),back('admin')))

@router.callback_query(F.data.startswith('changeshop:'))
async def change_shop_menu(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:sid=int(c.data.split(':')[1])
    except (ValueError,IndexError):return await c.answer('Некорректная смена',show_alert=True)
    shift=store.one("SELECT s.*,u.name FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.status='open'",(sid,))
    if not shift:return await c.answer('Открытая смена не найдена',show_alert=True)
    rows=[[btn(x['name'],f'setshiftshop:{sid}:{i}')] for i,x in enumerate(shops_now())]
    rows.append(back('working'))
    await reply(c,f'Исправить магазин смены №{sid}\nСотрудник: {esc(shift["name"])}\nСейчас: {esc(shift["shop"])}',keyboard(*rows))

@router.callback_query(F.data.startswith('setshiftshop:'))
async def set_shift_shop(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:
        _,raw_sid,raw_idx=c.data.split(':');sid=int(raw_sid);idx=int(raw_idx);items=shops_now();new_shop=items[idx]['name']
    except (ValueError,IndexError):return await c.answer('Устаревшая кнопка',show_alert=True)
    if not store.change_shift_shop(sid,new_shop,c.from_user.id,stamp()):return await c.answer('Смена уже закрыта или магазин недоступен',show_alert=True)
    await reply(c,f'✅ Магазин смены №{sid} изменён на {esc(new_shop)}.',keyboard(back('working')))

async def paged_users(c,p,mode):
    items=store.all("SELECT * FROM users WHERE status='approved' ORDER BY name,id")
    p=max(0,min(p,max(0,(len(items)-1)//8)));chunk=items[p*8:p*8+8]
    rows=[[btn(x['name'],f'accessuser:{x["id"]}:{p}' if mode=='access' else f'employee:{x["id"]}')] for x in chunk]
    nav=[]
    if p:nav.append(btn('◀️',f'{mode}:{p-1}'))
    nav.append(btn(f'{p+1}/{max(1,(len(items)+7)//8)}','noop'))
    if (p+1)*8<len(items):nav.append(btn('▶️',f'{mode}:{p+1}'))
    rows.extend([nav,back('admin')]);await reply(c,'🔐 Доступ' if mode=='access' else '👥 Сотрудники',keyboard(*rows))

async def render_access_user(c,uid,page):
    u=user(uid)
    if not u:return await c.answer('Сотрудник не найден',show_alert=True)
    managed=set(store.manager_shop_names(uid));rows=[]
    rows.append([btn(('✅' if u['list_access'] else '❌')+' Доступ к спискам',f'confirmtoggle:{uid}:{page}:{u["list_access"]}')])
    for idx,item in enumerate(shops_now()):
        rows.append([btn(('✅' if item['name'] in managed else '❌')+' Управляющий: '+item['name'],f'togglemanager:{uid}:{page}:{idx}')])
    rows.append(back(f'access:{page}'))
    await reply(c,'🔐 Доступ\n\nСотрудник: '+esc(u['name'])+'\nВыберите разрешения:',keyboard(*rows))

@router.callback_query(F.data.startswith('accessuser:'))
async def access_user(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:_,raw_uid,raw_page=c.data.split(':');uid=int(raw_uid);page=int(raw_page)
    except (ValueError,IndexError):return await c.answer('Устаревшая кнопка',show_alert=True)
    await render_access_user(c,uid,page)

@router.callback_query(F.data.startswith(('employees:','access:')))
async def users_page(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    mode,p=c.data.split(':');await paged_users(c,int(p),mode)

@router.callback_query(F.data.startswith('toggle:'))
async def toggle(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    _,uid,p=c.data.split(':')
    u=user(int(uid))
    if not u:return await c.answer('Сотрудник не найден',show_alert=True)
    await reply(c,f'Изменить доступ к спискам для {esc(u["name"])}?',keyboard([btn('✅ Подтвердить',f'confirmtoggle:{uid}:{p}:{u["list_access"]}')],[btn('❌ Отмена',f'access:{p}')]))

@router.callback_query(F.data.startswith('confirmtoggle:'))
async def confirm_toggle(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:_,uid,p,expected=c.data.split(':');uid=int(uid);p=int(p);expected=int(expected)
    except (ValueError,TypeError):return await c.answer('Устаревшая кнопка',show_alert=True)
    changed=store.run_update("UPDATE users SET list_access=? WHERE id=? AND status='approved' AND list_access=?",(1-expected,uid,expected))
    if changed:store.audit(c.from_user.id,'list_access_changed',f'{uid}:{1-expected}')
    else:await c.answer('Доступ уже изменён. Обновляю список.',show_alert=True)
    await render_access_user(c,uid,p)

@router.callback_query(F.data.startswith('togglemanager:'))
async def toggle_manager(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:
        _,raw_uid,raw_page,raw_idx=c.data.split(':');uid=int(raw_uid);page=int(raw_page);idx=int(raw_idx);item=shops_now()[idx];name=item['name']
    except (ValueError,IndexError):return await c.answer('Устаревшая кнопка',show_alert=True)
    if name in store.manager_shop_names(uid):
        store.remove_manager(uid,name);action='manager_removed'
    else:
        if not store.assign_manager(uid,name):return await c.answer('Не удалось назначить управляющего',show_alert=True)
        action='manager_assigned'
    store.audit(c.from_user.id,action,f'{uid}:{name}')
    await render_access_user(c,uid,page)

@router.callback_query(F.data.startswith('employee:'))
async def employee(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    uid=int(c.data.split(':')[1]);u=user(uid)
    if not u:return await c.answer('Сотрудник не найден',show_alert=True)
    await reply(c,'👤 '+esc(u['name']),keyboard([btn('📸 Отчёты',f'employee_records:report:{uid}:0')],[btn('📋 Списки',f'employee_records:list:{uid}:0')],[btn('📅 Календарь смен',f'calendar:{uid}:{now().strftime("%Y-%m")}')],[btn('📅 Все смены',f'employee_shifts:{uid}:0')],[btn('🚪 Уволить сотрудника',f'dismiss:{uid}')],back('employees:0')))

@router.callback_query(F.data.startswith('dismiss:'))
async def dismiss_employee_confirm(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:uid=int(c.data.split(':')[1])
    except (ValueError,IndexError):return await c.answer('Некорректный сотрудник',show_alert=True)
    if uid in ADMINS:return await c.answer('Главного администратора нельзя уволить через бота',show_alert=True)
    u=user(uid)
    if not u or u['status']!='approved':return await c.answer('Активный сотрудник не найден',show_alert=True)
    await reply(c,f'Уволить сотрудника {esc(u["name"])}?\n\nДоступ будет закрыт, назначения управляющего сняты, история сохранится.',keyboard([btn('✅ Подтвердить увольнение',f'dismissyes:{uid}')],[btn('❌ Отмена',f'employee:{uid}')]))

@router.callback_query(F.data.startswith('dismissyes:'))
async def dismiss_employee_apply(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:uid=int(c.data.split(':')[1])
    except (ValueError,IndexError):return await c.answer('Некорректный сотрудник',show_alert=True)
    if uid in ADMINS:return await c.answer('Главного администратора нельзя уволить через бота',show_alert=True)
    result=store.archive_employee(uid,c.from_user.id,stamp())
    if result=='open_shift':return await c.answer('Сначала необходимо закрыть открытую смену сотрудника',show_alert=True)
    if result!='archived':return await c.answer('Сотрудник уже уволен или не найден',show_alert=True)
    wake_outbox()
    await reply(c,'✅ Сотрудник переведён в архив. История смен и отчётов сохранена.',keyboard([btn('🗄 Открыть архив','archive:0')],back('admin')))

@router.callback_query(F.data.startswith('archive:'))
async def employee_archive(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:p=max(0,int(c.data.split(':')[1]))
    except (ValueError,IndexError):p=0
    items=store.all("SELECT id,name FROM users WHERE status='archived' ORDER BY name,id")
    if not items:return await reply(c,'🗄 Архив сотрудников\n\nАрхив пуст.',keyboard(back('admin')))
    pages=max(1,(len(items)+7)//8);p=min(p,pages-1);chunk=items[p*8:p*8+8]
    rows=[[btn(x['name'],f'archivedemployee:{x["id"]}:{p}')] for x in chunk];nav=[]
    if p:nav.append(btn('◀️',f'archive:{p-1}'))
    nav.append(btn(f'{p+1}/{pages}','noop'))
    if p+1<pages:nav.append(btn('▶️',f'archive:{p+1}'))
    rows.extend([nav,back('admin')]);await reply(c,'🗄 Архив сотрудников',keyboard(*rows))

@router.callback_query(F.data.startswith('archivedemployee:'))
async def archived_employee(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:_,raw_uid,raw_page=c.data.split(':');uid=int(raw_uid);page=int(raw_page)
    except (ValueError,IndexError):return await c.answer('Некорректная запись',show_alert=True)
    u=user(uid)
    if not u or u['status']!='archived':return await c.answer('Сотрудник не найден в архиве',show_alert=True)
    stats=store.one("SELECT COUNT(*) shifts,COALESCE(SUM(CASE WHEN status='closed' THEN pay ELSE 0 END),0) total FROM shifts WHERE user_id=?",(uid,))
    await reply(c,f'🗄 {esc(u["name"])}\nTelegram ID: {uid}\nСмен в истории: {stats["shifts"]}\nНачислено: {stats["total"]} ₽',keyboard([btn('📅 Календарь',f'calendar:{uid}:{now().strftime("%Y-%m")}')],back(f'archive:{page}')))

@router.callback_query(F.data.startswith('calendar:'))
async def shift_calendar(c:CallbackQuery):
    try:
        _,raw_uid,period=c.data.split(':');uid=int(raw_uid)
        year,month=map(int,period.split('-'))
        if not 2020<=year<=2100 or not 1<=month<=12:raise ValueError
    except (ValueError,IndexError):return await c.answer('Некорректный месяц',show_alert=True)
    if c.from_user.id!=uid and not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    first=date(year,month,1);last_day=calendar.monthrange(year,month)[1]
    rows=store.all("SELECT day,shop,status,pay FROM shifts WHERE user_id=? AND day>=? AND day<=? ORDER BY day",(uid,first.isoformat(),first.replace(day=last_day).isoformat()))
    by_day={int(x['day'][-2:]):x for x in rows}
    lines=[]
    for day in range(1,last_day+1):
        if day in by_day:
            x=by_day[day];lines.append(f'{day:02d} — {"✅" if x["status"]=="closed" else "🟢"} {esc(x["shop"])} · {x["pay"] if x["status"]=="closed" else 0} ₽')
    prev=(first-timedelta(days=1)).strftime('%Y-%m');nxt=(first.replace(day=last_day)+timedelta(days=1)).strftime('%Y-%m')
    parent=f'employee:{uid}' if admin(c.from_user.id) and c.from_user.id!=uid else 'profile'
    await reply(c,f'📅 Календарь {period}\n\n'+('\n'.join(lines) if lines else 'Смен нет.'),keyboard([btn('◀️',f'calendar:{uid}:{prev}'),btn('▶️',f'calendar:{uid}:{nxt}')],back(parent)))

@router.callback_query(F.data=='shops')
async def shops(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    counts={x['shop']:x['n'] for x in store.all('SELECT shop,COUNT(*) n FROM shifts GROUP BY shop')};items=shops_now();inactive=store.inactive_shops()
    text='\n'.join(f'{esc(x["name"])}: {counts.get(x["name"],0)} смен · {x["opening_hour"]:02d}:00–{x["closing_hour"]:02d}:00 · {x["pay"]} ₽' for x in items)
    if inactive:text+='\n\n🚫 Отключены:\n'+'\n'.join(f'{esc(x["name"])} · {x["opening_hour"]:02d}:00–{x["closing_hour"]:02d}:00 · {x["pay"]} ₽' for x in inactive)
    rows=[[btn('🏪 '+x['name'],f'shopview:{i}:0')] for i,x in enumerate(items)]
    rows.extend([[btn('✅ Включить '+x['name'],f'shopenable:{i}')] for i,x in enumerate(inactive)])
    rows.extend([[btn('➕ Добавить магазин','shopnew')],back('admin')])
    await reply(c,'🏪 Магазины\n\n'+text,keyboard(*rows))

@router.callback_query(F.data.startswith('shopenable:'))
async def shop_enable(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:item=store.inactive_shops()[int(c.data.split(':')[1])];name=item['name']
    except (ValueError,IndexError):return await c.answer('Устаревшая кнопка',show_alert=True)
    if not store.set_shop_active(name,True):return await c.answer('Магазин уже включён или не найден',show_alert=True)
    store.audit(c.from_user.id,'shop_enabled',name)
    await reply(c,f'✅ Магазин «{esc(name)}» снова включён.',keyboard([btn('🏪 К магазинам','shops')]))

@router.callback_query(F.data.startswith('shopview:'))
async def shop_view(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    
    try:
        _,idx,p=c.data.split(':');idx=int(idx);p=int(p)
        items=shops_now()
        if idx<0 or idx>=len(items) or p<0:raise ValueError('Invalid page')
    except (ValueError,IndexError):return await c.answer('Некорректный магазин или страница',show_alert=True)
    shop=items[idx]['name'];shifts=store.all('SELECT s.*,u.name FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.shop=? ORDER BY s.id DESC',(shop,))
    extra=lambda _:[[btn('✏️ Настройки',f'shopedit:{idx}'),btn('🚫 Отключить',f'shopdisable:{idx}')]]
    if not shifts:
        return await reply(c,'🏪 '+esc(shop)+'\n\nСмен пока нет.',keyboard([btn('✏️ Настройки',f'shopedit:{idx}'),btn('🚫 Отключить',f'shopdisable:{idx}')],back('shops')))
    await show_page(c,shifts,int(p),'🏪 '+shop,'shopview:'+str(idx),'shops',lambda x:f'{esc(x["name"])}\n{x["day"]} — {x["status"]}',extra)

@router.callback_query(F.data=='shopnew')
async def shop_new(c:CallbackQuery,state:FSMContext):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    await state.clear();await state.update_data(shop_mode='new');await state.set_state(S.shop_edit)
    await reply(c,'Введите данные магазина одним сообщением:\nНазвание | час открытия | час закрытия | ставка\n\nПример: Иркутск | 7 | 22 | 2300\nОтмена: /cancel')

@router.callback_query(F.data.startswith('shopedit:'))
async def shop_edit(c:CallbackQuery,state:FSMContext):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:item=shops_now()[int(c.data.split(':')[1])]
    except (ValueError,IndexError):return await c.answer('Устаревшая кнопка',show_alert=True)
    await state.clear();await state.update_data(shop_mode='edit',shop_name=item['name']);await state.set_state(S.shop_edit)
    await reply(c,f'Настройки «{esc(item["name"])}» сейчас: {item["opening_hour"]:02d}:00–{item["closing_hour"]:02d}:00, {item["pay"]} ₽.\n\nВведите: час открытия | час закрытия | ставка\nПример: 7 | 22 | 2300\nОтмена: /cancel')

@router.message(S.shop_edit,F.text)
async def shop_edit_save(m:Message,state:FSMContext):
    if not admin(m.from_user.id):await state.clear();return
    data=await state.get_data()
    try:
        parts=[x.strip() for x in m.text.split('|')]
        if data.get('shop_mode')=='new':name,opening,closing,pay=parts
        else:name=data['shop_name'];opening,closing,pay=parts
        store.save_shop(name,int(opening),int(closing),int(pay))
    except (ValueError,IndexError,KeyError):return await m.answer('Неверный формат. Используйте числа часов 0–23 и неотрицательную ставку.')
    store.audit(m.from_user.id,'shop_saved',name);await state.clear()
    await m.answer(f'✅ Магазин «{esc(name)}» сохранён.',reply_markup=keyboard([btn('🏪 К магазинам','shops')]))

@router.callback_query(F.data.startswith('shopdisable:'))
async def shop_disable_confirm(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:idx=int(c.data.split(':')[1]);item=shops_now()[idx]
    except (ValueError,IndexError):return await c.answer('Устаревшая кнопка',show_alert=True)
    await reply(c,f'Отключить магазин «{esc(item["name"])}»? История сохранится.',keyboard([btn('✅ Отключить',f'shopdisableyes:{idx}')],[btn('❌ Отмена',f'shopview:{idx}:0')]))

@router.callback_query(F.data.startswith('shopdisableyes:'))
async def shop_disable_apply(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:idx=int(c.data.split(':')[1]);item=shops_now()[idx];name=item['name']
    except (ValueError,IndexError):return await c.answer('Устаревшая кнопка',show_alert=True)
    if store.one("SELECT 1 FROM shifts WHERE shop=? AND status='open'",(name,)):return await c.answer('Сначала закройте или перенесите открытую смену',show_alert=True)
    store.set_shop_active(name,False);store.audit(c.from_user.id,'shop_disabled',name)
    await reply(c,f'✅ Магазин «{esc(name)}» отключён.',keyboard([btn('🏪 К магазинам','shops')]))

async def show_page(c,items,p,title,prefix,parent,format_item,extra=None):
    if not items:return await reply(c,title+'\n\nЗаписей нет.',keyboard(back(parent)))
    p=max(0,min(p,len(items)-1));x=items[p];nav=[]
    if p:nav.append(btn('◀️',f'{prefix}:{p-1}'))
    nav.append(btn(f'{p+1}/{len(items)}','noop'))
    if p+1<len(items):nav.append(btn('▶️',f'{prefix}:{p+1}'))
    rows=[nav]
    if extra:rows.extend(extra(x))
    rows.append(back(parent));await reply(c,title+'\n\n'+format_item(x)[:3200],keyboard(*rows))

async def records_page(c,kind,p,uid=None):
    if uid is None:
        items=store.all('SELECT r.*,u.name FROM records r JOIN users u ON u.id=r.user_id WHERE kind=? ORDER BY r.id DESC',(kind,));prefix=f'records:{kind}';parent='admin'
    else:
        items=store.all('SELECT r.*,u.name FROM records r JOIN users u ON u.id=r.user_id WHERE kind=? AND user_id=? ORDER BY r.id DESC',(kind,uid));prefix=f'employee_records:{kind}:{uid}';parent=f'employee:{uid}'
    def fmt(x):return f'№{x["id"]} — {esc(x["name"])}\n🏪 {esc(x["shop"])}\nДата: {esc(x["created"])}\nСтатус: {esc(x["status"])}\nКомментарий: {esc(x["admin_comment"] or "—")}'
    def extra(x):
        rows=[[btn('📎 Открыть файл',f'getfile:{x["id"]}')]]
        if x['status']=='pending':rows.append([btn('✅ Принять',f'accept:{x["id"]}'),btn('🔴 На исправление',f'revise:{x["id"]}')])
        return rows
    await show_page(c,items,p,'📸 Отчёты' if kind=='report' else '📋 Списки',prefix,parent,fmt,extra)

@router.callback_query(F.data.startswith('records:'))
async def all_records(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    _,kind,p=c.data.split(':');await records_page(c,kind,int(p))
@router.callback_query(F.data.startswith('employee_records:'))
async def employee_records(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    _,kind,uid,p=c.data.split(':');await records_page(c,kind,int(p),int(uid))

@router.callback_query(F.data.startswith('employee_shifts:'))
async def employee_shifts(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    _,uid,p=c.data.split(':');uid=int(uid);items=store.all('SELECT * FROM shifts WHERE user_id=? ORDER BY id DESC',(uid,))
    await show_page(c,items,int(p),'📅 История смен',f'employee_shifts:{uid}',f'employee:{uid}',lambda x:f'{esc(x["day"])}\n{esc(x["shop"])}\nСтатус: {x["status"]}\nОплата: {x["pay"] if x["status"]=="closed" else 0} ₽')

@router.callback_query(F.data.startswith('getfile:'))
async def getfile(c:CallbackQuery):
    rid=int(c.data.split(':')[1]);r=store.one('SELECT * FROM records WHERE id=?',(rid,))
    if not r:return await c.answer('Не найдено',show_alert=True)
    if not can_manage(c.from_user.id,r['shop']):return await c.answer('Нет доступа',show_alert=True)
    try:path=safe_path(r['path'])
    except ValueError:return await c.answer('Недопустимый путь к файлу',show_alert=True)
    if not path.is_file():return await c.answer('Локальный файл отсутствует',show_alert=True)
    if r['kind']=='report':
        if path.suffix.lower() in ('.jpg','.jpeg','.png'):await c.message.answer_photo(FSInputFile(path),caption=f'Фотоотчёт №{rid}')
        else:await c.message.answer_document(FSInputFile(path),caption=f'Фотоотчёт №{rid}')
    else:await c.message.answer_document(FSInputFile(path),caption=f'Список №{rid}')
    await c.answer()

@router.callback_query(F.data.startswith('accept:'))
async def accept(c:CallbackQuery):
    rid=int(c.data.split(':')[1]);r=store.one('SELECT * FROM records WHERE id=?',(rid,))
    if not r:return await c.answer('Не найдено',show_alert=True)
    if not can_manage(c.from_user.id,r['shop']):return await c.answer('Нет доступа',show_alert=True)
    if r['status']=='accepted':return await c.answer('Уже принято',show_alert=True)
    if r['status']=='superseded':return await c.answer('Эта версия заменена новой',show_alert=True)
    if not store.review(rid,c.from_user.id,'accepted'):
        return await c.answer('Запись уже обработана другим администратором',show_alert=True)
    wake_outbox()
    await reply(c,f'✅ Запись №{rid} принята.',keyboard(back('admin')))

@router.callback_query(F.data.startswith('revise:'))
async def revise(c:CallbackQuery,state:FSMContext):
    rid=int(c.data.split(':')[1]);r=store.one('SELECT * FROM records WHERE id=?',(rid,))
    if not r:return await c.answer('Не найдено',show_alert=True)
    if not can_manage(c.from_user.id,r['shop']):return await c.answer('Нет доступа',show_alert=True)
    if r['status']!='pending':return await c.answer('Запись уже рассмотрена',show_alert=True)
    await state.update_data(record_id=rid);await state.set_state(S.revision)
    await reply(c,f'Напишите причину исправления записи №{rid}. /cancel')
@router.message(S.revision,F.text)
async def revision_text(m:Message,state:FSMContext):
    d=await state.get_data();rid=d['record_id'];r=store.one('SELECT * FROM records WHERE id=?',(rid,))
    if not r:await state.clear();return await m.answer('Запись не найдена')
    if not can_manage(m.from_user.id,r['shop']):await state.clear();return await m.answer('Нет доступа')
    if not store.review(rid,m.from_user.id,'revision',m.text[:2000]):
        await state.clear();return await m.answer('Запись уже обработана другим администратором.')
    wake_outbox()
    await state.clear()
    await m.answer('Сотрудник уведомлён.',reply_markup=keyboard(back('admin')))

@router.callback_query(F.data.startswith('correct:'))
async def correct(c:CallbackQuery,state:FSMContext):
    if not allowed(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    try:rid=int(c.data.split(':')[1])
    except (ValueError,IndexError):return await c.answer('Неверная запись',show_alert=True)
    r=store.one("SELECT * FROM records WHERE id=? AND user_id=? AND status='revision'",(rid,c.from_user.id))
    if not r:return await c.answer('Нет записи для исправления',show_alert=True)
    await state.update_data(correction_id=rid)
    await state.set_state(S.correction_photo if r['kind']=='report' else S.correction_list)
    await reply(c,'📸 Отправьте новое фото для отчёта №'+str(rid) if r['kind']=='report' else '📋 Отправьте исправленный текст списка №'+str(rid))

async def finish_correction(m,state,kind):
    if not allowed(m.from_user.id):
        await state.clear();return await m.answer('Доступ отозван.')
    d=await state.get_data();rid=d.get('correction_id');r=eligible_record(m.from_user.id,rid,kind)
    if not r:await state.clear();return await m.answer('Запись больше не ожидает исправления.')
    folder=ROOT/'storage'/('reports' if kind=='report' else 'lists')/r['shop'];folder.mkdir(parents=True,exist_ok=True)
    media,ext=incoming_image(m) if kind=='report' else (None,'.txt')
    if kind=='report' and not media:return await m.answer('Отправьте JPG, PNG или WEBP.')
    path=folder/f"{r['shop']}_{m.from_user.id}_correction_{uuid.uuid4().hex}{ext}"
    file_id='';comment=''
    if kind=='report':
        if not has_storage_capacity(getattr(media,'file_size',0) or 0):return await m.answer('Хранилище заполнено. Сообщите администратору.')
        try:await bot.download(media,destination=path)
        except Exception:
            path.unlink(missing_ok=True)
            logging.exception('Correction image download failed')
            return await m.answer('Не удалось загрузить фото. Повторите отправку.')
        detected=detect_image(path)
        if not detected:
            path.unlink(missing_ok=True)
            return await m.answer('Некорректный формат изображения.')
        if detected!=ext:
            actual=path.with_suffix(detected);path.rename(actual);path=actual
        file_id=media.file_id
    else:
        if len(m.text)>30000:return await m.answer('Слишком длинный список (максимум 30 000 символов).')
        comment=m.text
        if not has_storage_capacity(len(m.text.encode('utf-8'))+500):return await m.answer('Хранилище заполнено. Сообщите администратору.')
        path.write_text(f'Исправление записи №{rid}\nМагазин: {r["shop"]}\nСотрудник: {user(m.from_user.id)["name"]}\n\n{comment}',encoding='utf-8')
    try:new_id=store.replace_record(rid,m.from_user.id,str(path),file_id,comment,stamp(),recipients_for(r['shop']))
    except Exception:
        path.unlink(missing_ok=True)
        logging.exception('Cannot save correction')
        return await m.answer('Ошибка сохранения исправления. Попробуйте ещё раз.')
    await state.clear()
    if not new_id:
        path.unlink(missing_ok=True)
        return await m.answer('Не удалось сохранить исправление; обратитесь к администратору.')
    store.audit(m.from_user.id,'record_correction',f'{rid}->{new_id}')
    wake_outbox()
    await m.answer('✅ Исправление отправлено на повторную проверку.',reply_markup=home_k(m.from_user.id))

@router.message(S.correction_photo,F.photo | F.document)
async def correction_photo(m:Message,state:FSMContext):await finish_correction(m,state,'report')
@router.message(S.correction_list,F.text)
async def correction_list(m:Message,state:FSMContext):await finish_correction(m,state,'list')

@router.callback_query(F.data=='announce')
async def announce(c:CallbackQuery,state:FSMContext):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    await state.set_state(S.announcement);await reply(c,'Введите текст объявления. /cancel')
@router.message(S.announcement,F.text)
async def announcement_preview(m:Message,state:FSMContext):
    if not admin(m.from_user.id):await state.clear();return
    if len(m.text)>3500:return await m.answer('Максимум 3500 символов.')
    await state.update_data(text=m.text);await state.set_state(S.announcement_confirm)
    await m.answer('📢 Предпросмотр:\n\n'+esc(m.text),reply_markup=keyboard([btn('📤 Отправить всем','announce_send')],[btn('❌ Отмена','announce_cancel')]))
@router.callback_query(F.data.in_({'announce_send','announce_cancel'}))
async def announce_confirm(c:CallbackQuery,state:FSMContext):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    if await state.get_state()!=S.announcement_confirm.state:return await c.answer('Нет ожидающего объявления',show_alert=True)
    d=await state.get_data();await state.clear()
    if c.data=='announce_cancel':return await reply(c,'Рассылка отменена.',keyboard(back('admin')))
    announcement_id=store.queue_announcement(c.from_user.id,d['text'])
    wake_outbox()
    await reply(c,f'Объявление №{announcement_id} поставлено в очередь доставки.',keyboard(back('admin')))

# Periods: 1st -> prior month 16th–end; 15th -> current month 1st–14th.
def period(day):
    if day.day==1:
        prev=day.replace(day=1)-timedelta(days=1)
        return prev.replace(day=16),prev
    return day.replace(day=1),day.replace(day=14)

def export_salary(start,end):
    rows=store.all("SELECT u.name,s.user_id,s.shop,COUNT(*) shifts,SUM(s.pay) salary FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.status='closed' AND s.day>=? AND s.day<=? GROUP BY s.user_id,s.shop ORDER BY u.name,s.shop",(start.isoformat(),end.isoformat()))
    wb=Workbook();sheet=wb.active;sheet.title='Зарплата'
    sheet.append(['Сотрудник','Telegram ID','Магазин','Смен','Начислено, ₽'])
    for x in rows:sheet.append([x['name'],str(x['user_id']),x['shop'],x['shifts'],x['salary']])
    for cell in sheet[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='402060')
    for col in 'ABCDE':sheet.column_dimensions[col].width=23
    folder=PAYROLL_EXPORT_DIR;folder.mkdir(parents=True,exist_ok=True)
    path=folder/f'SmoKing_{start.isoformat()}_{end.isoformat()}_{uuid.uuid4().hex[:12]}.xlsx'
    wb.save(path);return path

@router.callback_query(F.data=='paymenu')
async def paymenu(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    await reply(c,'💰 Зарплатные отчёты\n1 числа — 16–последний день прошлого месяца.\n15 числа — 1–14 текущего месяца.',keyboard([btn('📥 Последний расчётный период','payexport:last')],[btn('📥 Текущий месяц','payexport:month')],back('admin')))
@router.callback_query(F.data.startswith('payexport:'))
async def payexport(c:CallbackQuery):
    if not admin(c.from_user.id):return await c.answer('Нет доступа',show_alert=True)
    mode=c.data.split(':')[1];today=now().date()
    if mode=='last':
        if today.day>=15:start,end=today.replace(day=1),today.replace(day=14)
        else:
            prev=today.replace(day=1)-timedelta(days=1)
            start,end=prev.replace(day=16),prev
    else:start,end=today.replace(day=1),today
    try:path=await asyncio.to_thread(export_salary,start,end)
    except Exception:logging.exception('Excel generation failed');return await c.answer('Ошибка создания Excel, см. лог',show_alert=True)
    await c.message.answer_document(FSInputFile(path),caption=f'💰 {start} — {end}');await c.answer()

@router.callback_query(F.data=='noop')
async def noop(c:CallbackQuery):await c.answer()

@router.callback_query()
async def unknown(c:CallbackQuery):await c.answer('Кнопка устарела. Нажмите /start',show_alert=True)


@router.message(Command('retry_failed'))
async def retry_failed(m:Message):
    if not admin(m.from_user.id):return
    count=store.reset_failed_outbox()
    if count:wake_outbox()
    await m.answer(f'Повторно поставлено в очередь: {count}. Возможны дубликаты уже доставленных сообщений.')

@router.message(Command('check_files'))
async def check_files(m:Message):
    if not admin(m.from_user.id):return
    missing=store.attachment_health()
    await m.answer(f'Проверка вложений: отсутствует {len(missing)} файлов.'+(f' ID: {missing[:30]}' if missing else ''))

@router.message(Command('health'))
async def health_command(m:Message):
    if not staff(m.from_user.id):return
    stats=store.outbox_stats() or {'total':0,'failed':0};usage=storage_usage();free=shutil.disk_usage(ROOT).free
    backups=list((ROOT/'data'/'backups').glob('SmoKing_*.zip'))
    backup_text='нет'
    if backups:
        latest=max(backups,key=lambda p:p.stat().st_mtime)
        age=(now().timestamp()-latest.stat().st_mtime)/3600;backup_text=f'{latest.name}, {age:.1f} ч назад'
    await m.answer(f'🩺 Состояние SmoKing\nБаза: {"OK" if store.one("PRAGMA integrity_check").get("integrity_check")=="ok" else "ОШИБКА"}\nОчередь: {stats["total"] or 0}, ошибок: {stats["failed"] or 0}\nХранилище: {usage/1024**2:.1f} МБ\nСвободно на диске: {free/1024**3:.1f} ГБ\nПоследний бэкап: {backup_text}')

@router.message(Command('shop_add'))
async def shop_add_command(m:Message):
    if not admin(m.from_user.id):return
    try:
        payload=m.text.split(maxsplit=1)[1];name,opening,closing,pay=[x.strip() for x in payload.split('|')]
        store.save_shop(name,int(opening),int(closing),int(pay))
    except (ValueError,IndexError):return await m.answer('Формат: /shop_add Название | 7 | 22 | 2300')
    store.audit(m.from_user.id,'shop_saved',name);await m.answer(f'✅ Магазин «{esc(name)}» сохранён.')

@router.message(Command('shop_disable'))
async def shop_disable_command(m:Message):
    if not admin(m.from_user.id):return
    try:name=m.text.split(maxsplit=1)[1].strip()
    except IndexError:return await m.answer('Формат: /shop_disable Название')
    if current_count:=store.one("SELECT COUNT(*) n FROM shifts WHERE shop=? AND status='open'",(name,)):
        if current_count['n']:return await m.answer('Нельзя отключить магазин с открытой сменой.')
    changed=store.set_shop_active(name,False)
    if changed:store.audit(m.from_user.id,'shop_disabled',name)
    await m.answer('✅ Магазин отключён.' if changed else 'Магазин не найден.')

@router.message(Command('manager_add'))
async def manager_add_command(m:Message):
    if not admin(m.from_user.id):return
    try:
        raw_uid,name=[x.strip() for x in m.text.split(maxsplit=1)[1].split('|',1)];uid=int(raw_uid)
    except (ValueError,IndexError):return await m.answer('Формат: /manager_add TelegramID | Название магазина')
    if not store.assign_manager(uid,name):return await m.answer('Не найден одобренный сотрудник или активный магазин.')
    store.audit(m.from_user.id,'manager_assigned',f'{uid}:{name}');await m.answer(f'✅ Пользователь {uid} назначен управляющим магазина «{esc(name)}».')

@router.message(Command('manager_remove'))
async def manager_remove_command(m:Message):
    if not admin(m.from_user.id):return
    try:
        raw_uid,name=[x.strip() for x in m.text.split(maxsplit=1)[1].split('|',1)];uid=int(raw_uid)
    except (ValueError,IndexError):return await m.answer('Формат: /manager_remove TelegramID | Название магазина')
    changed=store.remove_manager(uid,name)
    if changed:store.audit(m.from_user.id,'manager_removed',f'{uid}:{name}')
    await m.answer('✅ Назначение удалено.' if changed else 'Назначение не найдено.')

@router.message()
async def fallback(m:Message,state:FSMContext):
    if await state.get_state():return await m.answer('Ожидается другой тип сообщения. Для отмены: /cancel')
    await m.answer('Используйте /start для открытия меню.')

async def deliver_outbox():
    # The scheduler and immediate worker may wake together. SQLite leases are
    # still the cross-process guard; this lock avoids redundant local claims.
    async with OUTBOX_DELIVERY_LOCK:
        entries=store.claim_outbox_batch(stamp(),limit=50)
        # Bounded concurrency: one blocked recipient must not stall everyone else.
        semaphore=asyncio.Semaphore(5)
        async def deliver_one(entry):
          async with semaphore:
            await _deliver_one(entry)
        await asyncio.gather(*(deliver_one(entry) for entry in entries))

async def outbox_worker():
    """Deliver new notifications immediately, with a periodic safety poll."""
    while True:
        try:
            await asyncio.wait_for(OUTBOX_WAKEUP.wait(),timeout=20)
        except asyncio.TimeoutError:
            pass
        # Clear before delivery: an event raised during delivery is retained
        # and starts another pass immediately.
        OUTBOX_WAKEUP.clear()
        try:
            await deliver_outbox()
        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception('Unexpected outbox worker failure')

async def _deliver_one(entry):
    uid=entry['recipient'];body=entry['body'];path=entry['path'] or None;markup=None
    if uid==0:
        store.complete_outbox(entry['id'],entry['lease_token'],stamp())
        return
    if body.startswith('SHIFTOPEN:') and entry['event_kind'] in ('legacy','text'):
        sid=int(body.split(':')[1]);sr=store.one('SELECT s.shop,u.name FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.id=?',(sid,))
        text=('🟢 Смена открыта\n👤 '+esc(sr['name'])+'\n🏪 '+esc(sr['shop'])) if sr else 'Смена не найдена'
    elif body.startswith('REGISTER:') and entry['event_kind'] in ('legacy','text'):
        registered_id=int(body.split(':')[1]);u=user(registered_id)
        if not u or u['status']!='pending':
            store.complete_outbox(entry['id'],entry['lease_token'],stamp());return
        text=f'👤 Заявка на регистрацию\nФИО: {esc(u["name"])}'
        markup=keyboard([btn('✅ Принять',f'approve:{registered_id}'),btn('❌ Отклонить',f'reject:{registered_id}')])
    elif body.startswith('REGRESULT:') and entry['event_kind'] in ('legacy','text'):
        parts=body.split(':');text='✅ Регистрация одобрена! /start' if parts[2]=='approved' else '❌ Регистрация отклонена. /start для повторной подачи.'
    elif body.startswith('REVIEW:') and entry['event_kind'] in ('legacy','text'):
        _,rid,status,comment=body.split(':',3)
        label='отчёт' if (store.one('SELECT kind FROM records WHERE id=?',(int(rid),)) or {}).get('kind')=='report' else 'список'
        text=f'{"✅" if status=="accepted" else "🔴"} Ваш {label} №{rid} '+('принят.' if status=='accepted' else 'требует исправления.\nПричина: '+esc(comment))
        if status=='revision':markup=keyboard([btn('🔄 Отправить исправление',f'correct:{rid}')])
    elif body.startswith('PAYROLL:') and entry['event_kind'] in ('legacy','text'):
        _,start,tail=body.split(':',2)
        end=tail.split('\n',1)[0]
        text=f'💰 Зарплатный отчёт {start} — {end}' + ('\n'+esc(tail.split('\n',1)[1]) if '\n' in tail else '')
    elif body.startswith('CORRECTION:') and entry['event_kind'] in ('legacy','text'):
        rid=int(body.split(':',1)[1]);r=store.one('SELECT r.*,u.name FROM records r JOIN users u ON u.id=r.user_id WHERE r.id=?',(rid,))
        if not r:
            store.complete_outbox(entry['id'],entry['lease_token'],stamp());return
        text=f'🔄 Исправление №{rid}\n🏪 {esc(r["shop"])}\n👤 {esc(r["name"])}'
        if can_manage(uid,r['shop']):markup=keyboard([btn('✅ Принять',f'accept:{rid}'),btn('🔴 На исправление',f'revise:{rid}')])
    elif body.startswith('ANNOUNCEMENT:') and entry['event_kind'] in ('legacy','text'):
        _,aid,content=body.split(':',2);text='📢 Объявление SmoKing\n\n'+esc(content)
    elif (body.startswith('LIST:') or body.startswith('REPORT:')) and entry['event_kind'] in ('legacy','text'):
        kind,rid=body.split(':',1);r=store.one('SELECT r.*,u.name FROM records r JOIN users u ON u.id=r.user_id WHERE r.id=?',(int(rid),))
        if not r:
            store.complete_outbox(entry['id'],entry['lease_token'],stamp());return
        text=f'{"📸 Отчёт" if kind=="REPORT" else "📋 Список"} №{rid}\n👤 {esc(r["name"])}\n🏪 {esc(r["shop"])}'
        if can_manage(uid,r['shop']):markup=keyboard([btn('✅ Принять',f'accept:{rid}'),btn('🔴 На исправление',f'revise:{rid}')])
    else:text=esc(body)
    try:
        if path:
            if body.startswith('PAYROLL:') or entry['event_kind']=='payroll':
                file=Path(path).resolve()
                if not (file.is_relative_to(PAYROLL_EXPORT_DIR.resolve()) or file.is_relative_to((ROOT/'salary_reports').resolve())):raise ValueError('Unsafe payroll file path')
            else:file=safe_path(path)
            if not file.is_file() and body.startswith('PAYROLL:'):
                raise FileNotFoundError('Original payroll export missing; regenerate a new revision instead of silently replacing it')
            if not file.is_file():raise FileNotFoundError(str(file))
            if file.stat().st_size>50*1024*1024:raise ValueError('Attachment exceeds Telegram document limit')
            if file.suffix.lower() in ('.jpg','.jpeg','.png') and entry['event_kind'] not in ('payroll',):
                await asyncio.wait_for(bot.send_photo(uid,FSInputFile(file),caption=html.escape(html.unescape(text)[:850],quote=False),reply_markup=markup),timeout=60)
            else:await asyncio.wait_for(bot.send_document(uid,FSInputFile(file),caption=html.escape(html.unescape(text)[:850],quote=False),reply_markup=markup),timeout=60)
        else:await asyncio.wait_for(bot.send_message(uid,html.unescape(text)[:3800],reply_markup=markup,parse_mode=None),timeout=30)
    except Exception as exc:
        store.fail_outbox(entry['id'],entry['lease_token'],str(exc)[:300],stamp())
        if entry['attempts'] in (0,2,9):store.record_delivery_error(uid,str(exc))
        logging.exception('Outbox delivery failed %s',entry['id'])
    else:store.complete_outbox(entry['id'],entry['lease_token'],stamp())

async def reminder():
    """At closing time, notify the employee and all admins, then repeat every hour.
    Notifications are durable and deduplicated per shift and hour.
    No automatic shift closure or salary credit occurs.
    """
    moment=now()
    for shift in store.all("SELECT s.*,u.name FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.status='open'"):
        configured=store.shop(shift['shop'])
        closing=configured['closing_hour'] if configured else STORE_CLOSING_HOURS.get(shift['shop'],23)
        shift_day=date.fromisoformat(shift['day'])
        if moment.date()<shift_day or (moment.date()==shift_day and moment.hour<closing):continue
        # At closing, once more the next morning, then once daily; avoid night-time spam.
        interval=int((moment.replace(tzinfo=None)-datetime.combine(shift_day,datetime.min.time()).replace(hour=closing)).total_seconds()//3600)
        if interval<0:continue
        if interval>0 and moment.date()>shift_day and moment.hour<10:continue
        slot=f'{shift["id"]}:{0 if interval==0 else moment.date().isoformat()}'
        employee_text=f'⚠️ Не отправлен фотоотчёт! Смена {shift["day"]}, магазин {shift["shop"]}. Отправьте отчёт, чтобы закрыть смену. Напоминание {slot}.'
        admin_text=f'⚠️ Нет фотоотчёта: {shift["name"]} (ID {shift["user_id"]}), магазин {shift["shop"]}, смена {shift["day"]}. Напоминание {slot}.'
        if store.queue_reminder(slot,shift['user_id'],employee_text,recipients_for(shift['shop']),admin_text,stamp()):
            wake_outbox()

def payroll_fingerprint(start, end):
    """Stable fingerprint of the exact closed shifts included in a payroll period."""
    rows = store.all("""SELECT s.id,s.user_id,s.shop,s.day,s.pay,u.name
                        FROM shifts s JOIN users u ON u.id=s.user_id
                        WHERE s.status='closed' AND s.day>=? AND s.day<=?
                        ORDER BY s.id""", (start.isoformat(), end.isoformat()))
    payload = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()[:20]

async def payroll_daily():
    today=now().date()
    # Catch up on any missed 1st/15th runs from the last 60 days.
    due=[today-timedelta(days=i) for i in range(60,-1,-1) if (today-timedelta(days=i)).day in (1,15)]
    launch=store.get_setting('payroll_start_date')
    if not launch:
        launch=today.isoformat();store.set_setting('payroll_start_date',launch)
    for due_day in due:
        if due_day.isoformat()<launch:continue
        start,end=period(due_day)
        pending=store.one("SELECT COUNT(*) AS n FROM shifts WHERE status='open' AND day>=? AND day<=?",(start.isoformat(),end.isoformat()))
        if pending and pending['n']:
            logging.warning('Payroll %s-%s postponed: %s open shifts',start,end,pending['n'])
            continue
        fingerprint=payroll_fingerprint(start,end)
        approved=store.get_setting('payroll_approved:'+f'{start}:{end}')
        if approved and approved!=fingerprint:
            logging.error('Approved payroll changed for %s-%s; requires administrator review',start,end)
            continue
        recipients=[]
        for uid in ADMINS:
            key=f'salary-v2:{due_day.isoformat()}:{uid}:{fingerprint}'
            if not store.one('SELECT 1 FROM jobs WHERE key=?',(key,)):
                recipients.append((uid,key))
        if not recipients:continue
        try:path=await asyncio.to_thread(export_salary,start,end)
        except Exception:logging.exception('Salary export failed for %s',due_day);continue
        # Detect changes during Excel generation; retry on the next scheduler run.
        if payroll_fingerprint(start,end)!=fingerprint:
            path.unlink(missing_ok=True)
            logging.warning('Payroll changed during export: %s-%s',start,end)
            continue
        previous=store.one('SELECT 1 FROM jobs WHERE key LIKE ? LIMIT 1',(f'salary-v2:{due_day.isoformat()}:%',))
        for uid,key in recipients:
            caption=f'PAYROLL:{start}:{end}'
            if previous:caption+=f'\n⚠️ Обновлённая ведомость (изменились закрытые смены). Версия {fingerprint}.'
            if store.claim_payroll_and_queue(key,uid,caption,str(path),stamp()):
                wake_outbox()

async def backup_daily():
    async with STORAGE_LOCK:
        return await _backup_daily_locked()

async def _backup_daily_locked():
    """Snapshot DB and referenced files; atomically publish only verified backups.

    A database+filesystem backup cannot be fully atomic without filesystem snapshots.
    Fail closed if referenced attachments change while being archived.
    """
    folder=ROOT/'data'/'backups';folder.mkdir(parents=True,exist_ok=True)
    day=now().date().isoformat()
    archive=folder/f'SmoKing_{day}.zip'
    tmp=folder/f'.SmoKing_{day}.{uuid.uuid4().hex}.tmp.zip'
    try:
        with tempfile.TemporaryDirectory(prefix='smoking-backup-') as scratch:
            snapshot=Path(scratch)/'smoking.sqlite3'
            with closing(sqlite3.connect(store.DB)) as src, closing(sqlite3.connect(snapshot)) as target:
                src.backup(target)
            with closing(sqlite3.connect(snapshot)) as db:
                if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise RuntimeError('SQLite integrity check failed')
                referenced=[row[0] for row in db.execute('SELECT path FROM records WHERE path IS NOT NULL')]
            attachments=[]
            for raw in referenced:
                file=Path(raw)
                if not file.is_absolute():file=ROOT/file
                file=file.resolve()
                if not file.is_relative_to((ROOT/'storage').resolve()) or not file.is_file():
                    raise RuntimeError(f'Missing or unsafe attachment: {raw}')
                attachments.append(file)
            with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED) as z:
                manifest={}
                for file, arcname in [(snapshot,'data/smoking.sqlite3')]+[(f,f.relative_to(ROOT).as_posix()) for f in sorted(set(attachments))]:
                    before=file.stat()
                    content=file.read_bytes()
                    after=file.stat()
                    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
                        raise RuntimeError(f'Attachment changed during backup: {file}')
                    z.writestr(arcname,content)
                    manifest[arcname]=hashlib.sha256(content).hexdigest()
                z.writestr('manifest.sha256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
            with zipfile.ZipFile(tmp) as z:
                if z.testzip() is not None:raise RuntimeError('Corrupt backup archive')
                hashes=json.loads(z.read('manifest.sha256.json'))
                for member,expected in hashes.items():
                    if hashlib.sha256(z.read(member)).hexdigest()!=expected:
                        raise RuntimeError(f'Backup checksum mismatch: {member}')
                for file in attachments:
                    if file.relative_to(ROOT).as_posix() not in z.namelist():
                        raise RuntimeError(f'Missing archived attachment: {file}')
            # Trial restore into an isolated temporary directory (never touch live data).
            with tempfile.TemporaryDirectory(prefix='smoking-restore-check-') as verify_dir:
                dest=Path(verify_dir).resolve()
                with zipfile.ZipFile(tmp) as z:
                    for item in z.infolist():
                        restored=(dest/item.filename).resolve()
                        if not restored.is_relative_to(dest):raise RuntimeError('Unsafe archive entry')
                        if item.is_dir():continue
                        restored.parent.mkdir(parents=True,exist_ok=True)
                        with z.open(item) as src, restored.open('wb') as dst:
                            shutil.copyfileobj(src,dst)
                restored_db=dest/'data'/'smoking.sqlite3'
                with closing(sqlite3.connect(restored_db)) as db:
                    if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                        raise RuntimeError('Restored SQLite integrity check failed')
                    for (raw,) in db.execute('SELECT path FROM records WHERE path IS NOT NULL'):
                        original=Path(raw)
                        if original.is_absolute():
                            original=original.resolve()
                            if not original.is_relative_to(ROOT.resolve()):raise RuntimeError('Unsafe attachment reference')
                            relative=original.relative_to(ROOT.resolve())
                        else:relative=original
                        if not (dest/relative).is_file():raise RuntimeError(f'Missing restored file: {relative}')
            tmp.replace(archive)
        for old in sorted(folder.glob('SmoKing_*.zip'))[:-14]:old.unlink(missing_ok=True)
    finally:
        tmp.unlink(missing_ok=True)


async def cleanup_temp():
    cutoff=now().timestamp()-3*86400
    # Never delete an image referenced by a shift/report or an active FSM session.
    referenced={str(Path(r['path']).resolve()) for r in store.all('SELECT path FROM records') if r['path']}
    for row in store.all('SELECT key,value FROM fsm'):
        with suppress(ValueError,KeyError,TypeError):
            state_data=json.loads(row['value']);updated=state_data.get('updated_at')
            if updated and datetime.fromisoformat(updated).timestamp()<cutoff:
                store.run('DELETE FROM fsm WHERE key=? AND value=?',(row['key'],row['value']))
                continue
            path=state_data.get('data',{}).get('path')
            if path:referenced.add(str(Path(path).resolve()))
    base=ROOT/'storage'/'reports'
    if base.exists():
        for p in base.rglob('*'):
            if p.is_file() and str(p.resolve()) not in referenced and p.stat().st_mtime<cutoff:
                with suppress(OSError):p.unlink()

async def alert_failures():
    stats=store.outbox_stats()
    if not stats or not stats['failed']:return
    # Once per day, with a stable unique key to prevent notification storms.
    for uid in ADMINS:
        store.queue_many([uid],f'⚠️ SmoKing: {stats["failed"]} уведомлений не доставлены после 12 попыток. Проверьте журнал и базу outbox. Дата: {now().date()}')
    wake_outbox()

async def stale_shift_monitor():
    """Notify once per day about shifts left open from an earlier date."""
    today=now().date().isoformat();queued=False
    for shift in store.all("SELECT s.*,u.name FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.status='open' AND s.day<?",(today,)):
        key=f'stale_shift:{shift["id"]}:{today}'
        if not store.claim_job(key,stamp()):continue
        employee=f'⚠️ У вас не закрыта смена за {shift["day"]}, магазин {shift["shop"]}. Отправьте фотоотчёт и закройте смену.'
        admin_text=f'⚠️ Незакрытая смена со вчерашнего дня: {shift["name"]} (ID {shift["user_id"]}), {shift["shop"]}, дата {shift["day"]}.'
        store.queue_many([shift['user_id']],employee)
        store.queue_many(recipients_for(shift['shop']),admin_text)
        queued=True
    if queued:wake_outbox()

async def health_monitor():
    """Alert main administrators about operational problems once per day."""
    issues=[];today=now().date().isoformat()
    try:
        integrity=store.one('PRAGMA integrity_check')
        if not integrity or integrity.get('integrity_check')!='ok':issues.append('ошибка целостности SQLite')
        if shutil.disk_usage(ROOT).free<1024**3:issues.append('на диске осталось меньше 1 ГБ')
        backups=list((ROOT/'data'/'backups').glob('SmoKing_*.zip'))
        if not backups:issues.append('нет резервной копии')
        elif now().timestamp()-max(p.stat().st_mtime for p in backups)>36*3600:issues.append('последний бэкап старше 36 часов')
        stats=store.outbox_stats()
        if stats and stats['failed']:issues.append(f'недоставленных сообщений: {stats["failed"]}')
    except Exception as exc:
        logging.exception('Health monitor failed');issues.append('ошибка самопроверки: '+str(exc)[:120])
    if issues and store.claim_job('health_alert:'+today,stamp()):
        store.queue_many(ADMINS,'🩺 Проблемы SmoKing:\n• '+'\n• '.join(issues));wake_outbox()

def scheduler_error_listener(event):
    if not event.exception:return
    logging.error('Scheduled job %s failed',event.job_id,exc_info=(type(event.exception),event.exception,event.exception.__traceback__))
    key=f'job_error:{event.job_id}:{now().strftime("%Y-%m-%d-%H")}'
    if store.claim_job(key,stamp()):
        store.queue_many(ADMINS,f'⚠️ Фоновая задача {event.job_id} завершилась с ошибкой: {str(event.exception)[:300]}')
        wake_outbox()

def configure_logging():
    log_dir=ROOT/'data'/'logs';log_dir.mkdir(parents=True,exist_ok=True)
    root_logger=logging.getLogger();root_logger.setLevel(logging.INFO)
    if not any(isinstance(h,RotatingFileHandler) for h in root_logger.handlers):
        handler=RotatingFileHandler(log_dir/'smoking.log',maxBytes=5*1024*1024,backupCount=5,encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s'))
        root_logger.addHandler(handler)

async def main():
    global bot
    if not TOKEN or not ADMINS:raise RuntimeError('Укажите BOT_TOKEN и ADMIN_IDS в .env')
    logging.basicConfig(level=logging.INFO);configure_logging()
    global LOCK_FILE
    LOCK_FILE=open(ROOT/'smoking.lock','a+b')
    if os.name=='nt':
        import msvcrt
        LOCK_FILE.seek(0);LOCK_FILE.write(b'0');LOCK_FILE.flush();LOCK_FILE.seek(0)
        try:msvcrt.locking(LOCK_FILE.fileno(),msvcrt.LK_NBLCK,1)
        except OSError as exc:raise RuntimeError('Another bot instance is running') from exc
    else:
        import fcntl
        try:fcntl.flock(LOCK_FILE,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as exc:raise RuntimeError('Another bot instance is running') from exc
    store.init();store.migrate_legacy()
    bot=Bot(TOKEN,default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp=Dispatcher(storage=SQLiteFSMStorage());dp.include_router(router)
    from app.middleware.throttling import ThrottlingMiddleware
    throttle=ThrottlingMiddleware()
    dp.message.middleware(throttle);dp.callback_query.middleware(throttle)
    scheduler=AsyncIOScheduler(timezone=TZ)
    scheduler.add_listener(scheduler_error_listener,EVENT_JOB_ERROR)
    scheduler.add_job(reminder,'cron',minute=0,id='reminder',misfire_grace_time=3600)
    scheduler.add_job(payroll_daily,'cron',hour=9,minute=0,id='payroll',misfire_grace_time=86400)
    scheduler.add_job(backup_daily,'cron',hour=3,minute=0,id='backup')
    scheduler.add_job(cleanup_temp,'cron',hour=4,id='cleanup')
    scheduler.add_job(alert_failures,'cron',hour=11,id='delivery_alerts')
    scheduler.add_job(stale_shift_monitor,'interval',minutes=15,id='stale_shifts',max_instances=1)
    scheduler.add_job(health_monitor,'interval',minutes=10,id='health_monitor',max_instances=1)
    scheduler.start()
    outbox_task=asyncio.create_task(outbox_worker(),name='outbox-worker')
    wake_outbox()
    try:
        for label, job in [('backup',backup_daily),('payroll',payroll_daily),('reminders',reminder),('stale shifts',stale_shift_monitor),('health',health_monitor)]:
            try:await job()
            except Exception:logging.exception('Startup task %s failed; polling will continue',label)
        while True:
            try:
                await dp.start_polling(bot)
                break
            except TelegramNetworkError as exc:
                logging.warning('Telegram is unavailable during polling startup; retrying in 10 seconds: %s',exc)
                await asyncio.sleep(10)
    finally:
        outbox_task.cancel()
        with suppress(asyncio.CancelledError):await outbox_task
        scheduler.shutdown(wait=False);await bot.session.close()


