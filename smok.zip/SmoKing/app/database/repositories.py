from app.database.store import all, one, run, run_update
