import sqlite3, json, shutil, os
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime
BASE=Path(__file__).resolve().parents[2]
DB=BASE/'data'/'smoking.sqlite3'
DB.parent.mkdir(exist_ok=True)

@contextmanager
def connect():
    c=sqlite3.connect(DB,timeout=30)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA busy_timeout=30000')
    c.execute('PRAGMA foreign_keys=ON')
    try:
        with c:yield c
    finally:c.close()

def init():
    with connect() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',username TEXT DEFAULT '',list_access INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS shifts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,shop TEXT NOT NULL,day TEXT NOT NULL,opened TEXT NOT NULL,closed TEXT,status TEXT NOT NULL DEFAULT 'open',pay INTEGER NOT NULL DEFAULT 2300,UNIQUE(user_id,day));
        CREATE UNIQUE INDEX IF NOT EXISTS one_open_shift ON shifts(user_id) WHERE status='open';
        CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL CHECK(kind IN ('report','list')),user_id INTEGER NOT NULL,shift_id INTEGER,shop TEXT NOT NULL,category TEXT NOT NULL DEFAULT '',path TEXT NOT NULL,file_id TEXT DEFAULT '',comment TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'pending',admin_comment TEXT DEFAULT '',created TEXT NOT NULL,reviewed_by INTEGER);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,actor INTEGER,action TEXT NOT NULL,detail TEXT,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs(key TEXT PRIMARY KEY,done TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient INTEGER NOT NULL,body TEXT NOT NULL,path TEXT,buttons TEXT,created TEXT NOT NULL,delivered TEXT,attempts INTEGER NOT NULL DEFAULT 0,last_error TEXT,UNIQUE(recipient,body,path));
        CREATE TABLE IF NOT EXISTS announcements(id INTEGER PRIMARY KEY AUTOINCREMENT,actor INTEGER NOT NULL,body TEXT NOT NULL,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS fsm(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS delivery_failures(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient INTEGER,detail TEXT,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS shops(name TEXT PRIMARY KEY,opening_hour INTEGER NOT NULL DEFAULT 7 CHECK(opening_hour BETWEEN 0 AND 23),closing_hour INTEGER NOT NULL CHECK(closing_hour BETWEEN 0 AND 23),pay INTEGER NOT NULL DEFAULT 2300 CHECK(pay>=0),active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)));
        CREATE TABLE IF NOT EXISTS manager_shops(user_id INTEGER NOT NULL,shop TEXT NOT NULL,PRIMARY KEY(user_id,shop),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(shop) REFERENCES shops(name) ON UPDATE CASCADE ON DELETE CASCADE);
        
        ''')
        if 'last_attempt' not in {r[1] for r in c.execute('PRAGMA table_info(outbox)')}:c.execute('ALTER TABLE outbox ADD COLUMN last_attempt TEXT')
        if 'lease_token' not in {r[1] for r in c.execute('PRAGMA table_info(outbox)')}:c.execute('ALTER TABLE outbox ADD COLUMN lease_token TEXT')
        if 'lease_until' not in {r[1] for r in c.execute('PRAGMA table_info(outbox)')}:c.execute('ALTER TABLE outbox ADD COLUMN lease_until TEXT')
        c.execute('''CREATE TABLE IF NOT EXISTS outbox_meta(outbox_id INTEGER PRIMARY KEY,kind TEXT NOT NULL DEFAULT 'text',payload TEXT NOT NULL DEFAULT '',FOREIGN KEY(outbox_id) REFERENCES outbox(id));''')
        cols={r[1] for r in c.execute('PRAGMA table_info(records)')}
        if 'parent_id' not in cols:c.execute('ALTER TABLE records ADD COLUMN parent_id INTEGER')
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS record_one_report_per_shift ON records(shift_id) WHERE kind='report' AND parent_id IS NULL AND shift_id IS NOT NULL")
        c.execute('CREATE TABLE IF NOT EXISTS incoming_messages(chat_id INTEGER NOT NULL,message_id INTEGER NOT NULL,record_id INTEGER NOT NULL,PRIMARY KEY(chat_id,message_id))')
        from config import STORE_CLOSING_HOURS, PAY_PER_SHIFT
        for name, closing_hour in STORE_CLOSING_HOURS.items():
            c.execute('INSERT OR IGNORE INTO shops(name,opening_hour,closing_hour,pay,active) VALUES(?,7,?,?,1)',(name,closing_hour,PAY_PER_SHIFT))

def all(sql,args=()):
    with connect() as c:return [dict(x) for x in c.execute(sql,args).fetchall()]
def one(sql,args=()):
    with connect() as c:
        r=c.execute(sql,args).fetchone();return dict(r) if r else None
def run(sql,args=()):
    with connect() as c:return c.execute(sql,args).lastrowid
def run_update(sql,args=()):
    with connect() as c:return c.execute(sql,args).rowcount

def get_setting(key):
    r=one('SELECT value FROM settings WHERE key=?',(key,))
    return r['value'] if r else None

def set_setting(key,value):
    run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,value))

def active_shops():
    return all('SELECT name,opening_hour,closing_hour,pay FROM shops WHERE active=1 ORDER BY name')

def inactive_shops():
    return all('SELECT name,opening_hour,closing_hour,pay FROM shops WHERE active=0 ORDER BY name')

def shop(name):
    return one('SELECT * FROM shops WHERE name=?',(name,))

def save_shop(name,opening_hour,closing_hour,pay):
    name=' '.join(str(name).split())
    if not name or len(name)>80 or not 0<=opening_hour<=23 or not 0<=closing_hour<=23 or pay<0:
        raise ValueError('Invalid shop settings')
    run('INSERT INTO shops(name,opening_hour,closing_hour,pay,active) VALUES(?,?,?,?,1) ON CONFLICT(name) DO UPDATE SET opening_hour=excluded.opening_hour,closing_hour=excluded.closing_hour,pay=excluded.pay,active=1',(name,opening_hour,closing_hour,pay))

def set_shop_active(name,active):
    return run_update('UPDATE shops SET active=? WHERE name=?',(int(bool(active)),name))

def manager_shop_names(uid):
    return [r['shop'] for r in all('SELECT shop FROM manager_shops WHERE user_id=? ORDER BY shop',(uid,))]

def assign_manager(uid,shop_name):
    with connect() as c:
        if not c.execute("SELECT 1 FROM users WHERE id=? AND status='approved'",(uid,)).fetchone():return False
        if not c.execute('SELECT 1 FROM shops WHERE name=? AND active=1',(shop_name,)).fetchone():return False
        c.execute('INSERT OR IGNORE INTO manager_shops(user_id,shop) VALUES(?,?)',(uid,shop_name))
        return True

def remove_manager(uid,shop_name):
    return run_update('DELETE FROM manager_shops WHERE user_id=? AND shop=?',(uid,shop_name))

def archive_employee(uid,actor,ts):
    """Archive an employee atomically while preserving all historical data."""
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        employee=c.execute('SELECT status FROM users WHERE id=?',(uid,)).fetchone()
        if not employee or employee['status']!='approved':return 'not_found'
        if c.execute("SELECT 1 FROM shifts WHERE user_id=? AND status='open'",(uid,)).fetchone():return 'open_shift'
        c.execute("UPDATE users SET status='archived',list_access=0 WHERE id=?",(uid,))
        c.execute('DELETE FROM manager_shops WHERE user_id=?',(uid,))
        queue(c,uid,'Ваш доступ к SmoKing отключён администратором. История смен сохранена.',ts=ts)
        c.execute('INSERT INTO audit(actor,action,detail,created) VALUES(?,?,?,?)',(actor,'employee_archived',str(uid),ts))
        return 'archived'

def notification_recipients(shop_name,main_admins=()):
    rows=all('SELECT user_id FROM manager_shops WHERE shop=?',(shop_name,))
    return set(main_admins)|{r['user_id'] for r in rows}

def change_shift_shop(shift_id,new_shop,actor,ts):
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        target=c.execute('SELECT pay FROM shops WHERE name=? AND active=1',(new_shop,)).fetchone()
        shift=c.execute("SELECT shop FROM shifts WHERE id=? AND status='open'",(shift_id,)).fetchone()
        if not target or not shift:return False
        c.execute('UPDATE shifts SET shop=?,pay=? WHERE id=?',(new_shop,target['pay'],shift_id))
        c.execute('INSERT INTO audit(actor,action,detail,created) VALUES(?,?,?,?)',(actor,'shift_shop_changed',f'{shift_id}:{shift["shop"]}->{new_shop}',ts))
        return True

def claim_job(key,ts):
    with connect() as c:
        return c.execute('INSERT OR IGNORE INTO jobs(key,done) VALUES(?,?)',(key,ts)).rowcount==1

def audit(actor,action,detail=''):
    run('INSERT INTO audit(actor,action,detail,created) VALUES(?,?,?,?)',(actor,action,detail,datetime.now().isoformat(timespec='seconds')))
def submit_registration(uid,name,username,admins,ts):
    """Create registration and administrator notifications atomically."""
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT status FROM users WHERE id=?',(uid,)).fetchone()
        if old and old['status']!='rejected':return False
        c.execute("INSERT INTO users(id,name,status,username) VALUES(?,?,'pending',?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,username=excluded.username,status='pending'",(uid,name,username))
        for recipient in set(admins):queue(c,recipient,f'REGISTER:{uid}:{ts}',ts=ts)
        return True

def open_shift(uid,shop,day,ts,admins=(),employee_name=""):
    try:
        with connect() as c:
            configured=c.execute('SELECT pay FROM shops WHERE name=? AND active=1',(shop,)).fetchone()
            if not configured:return False
            cur=c.execute('INSERT INTO shifts(user_id,shop,day,opened,pay) VALUES(?,?,?,?,?)',(uid,shop,day,ts,configured['pay']))
            for recipient in set(admins):queue(c,recipient,f'SHIFTOPEN:{cur.lastrowid}',ts=ts)
        return True
    except sqlite3.IntegrityError:return False

def close_shift(uid,shop,shift_id,path,file_id,comment,ts,admins=()):
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute("SELECT id FROM shifts WHERE id=? AND user_id=? AND status='open'",(shift_id,uid)).fetchone()
        if not row:return None
        c.execute("UPDATE shifts SET status='closed',closed=? WHERE id=?",(ts,shift_id))
        cur=c.execute("INSERT INTO records(kind,user_id,shift_id,shop,category,path,file_id,comment,created) VALUES('report',?,?,?,?,?,?,?,?)",(uid,shift_id,shop,'',path,file_id,comment,ts))
        for admin_id in set(admins):queue(c, admin_id, 'REPORT:' + str(cur.lastrowid), path, '', ts)
        # A late report can change a previously exported period: alert administrators.
        prior=c.execute("SELECT key FROM jobs WHERE key LIKE 'salary:%' AND done IS NOT NULL").fetchall()
        from datetime import date, timedelta
        workday=date.fromisoformat(c.execute('SELECT day FROM shifts WHERE id=?',(shift_id,)).fetchone()[0])
        for job in prior:
            try:
                export_day=date.fromisoformat(job['key'].split(':')[1])
                if export_day.day==1:
                    end=export_day.replace(day=1)-timedelta(days=1)
                    start=end.replace(day=16)
                elif export_day.day==15:
                    start=export_day.replace(day=1);end=export_day.replace(day=14)
                else:continue
                if start<=workday<=end:
                    for admin_id in set(admins):queue(c,admin_id,f'⚠️ После формирования ведомости {start} — {end} закрыта смена за {workday} (сотрудник ID {uid}). Пересоздайте и проверьте Excel. Запись №{cur.lastrowid}.',ts=ts)
            except (ValueError,IndexError):continue
        return cur.lastrowid

def queue(c, recipient, body, path='', buttons='', ts=None, kind='text', payload=''):
    cur=c.execute('INSERT OR IGNORE INTO outbox(recipient,body,path,buttons,created) VALUES(?,?,?,?,?)', (recipient,body,path or '',buttons or '',ts or datetime.now().isoformat(timespec='seconds')))
    if cur.rowcount:
        c.execute('INSERT INTO outbox_meta(outbox_id,kind,payload) VALUES(?,?,?)',(cur.lastrowid,kind,payload))
    return cur.rowcount > 0

def queue_many(recipients, body, path='', buttons='', kind='text', payload=''):
    with connect() as c:
        for uid in set(recipients):queue(c,uid,body,path,buttons,kind=kind,payload=payload)

def review(rid, actor, status, comment=''):
    if status not in ('accepted','revision'):raise ValueError('Invalid status')
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        r=c.execute('SELECT * FROM records WHERE id=?',(rid,)).fetchone()
        if not r or r['status']!='pending':return False
        updated=c.execute("UPDATE records SET status=?,admin_comment=?,reviewed_by=? WHERE id=? AND status='pending'",(status,comment,actor,rid)).rowcount
        if not updated:return False
        queue(c,r['user_id'],f'REVIEW:{rid}:{status}:{comment}')
        c.execute('INSERT INTO audit(actor,action,detail,created) VALUES(?,?,?,?)',(actor,'review_'+status,str(rid),datetime.now().isoformat(timespec='seconds')))
        return True

def queue_announcement(actor,body):
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        cur=c.execute('INSERT INTO announcements(actor,body,created) VALUES(?,?,?)',(actor,body,datetime.now().isoformat(timespec='seconds')))
        announcement_id=cur.lastrowid
        for r in c.execute("SELECT id FROM users WHERE status='approved'").fetchall():
            queue(c,r['id'],f'ANNOUNCEMENT:{announcement_id}:{body}')
        return announcement_id

def record_delivery_error(recipient,detail):
    run('INSERT INTO delivery_failures(recipient,detail,created) VALUES(?,?,?)',(recipient,str(detail)[:400],datetime.now().isoformat(timespec='seconds')))

def migrate_legacy():
    # Optional one-time migration from the previous JSON release; backup originals first.
    data=BASE/'data'
    files={n:data/(n+'.json') for n in ('users','shifts','reports','lists')}
    if not any(p.exists() for p in files.values()):return 0
    if one('SELECT id FROM users LIMIT 1') or one('SELECT id FROM shifts LIMIT 1') or one('SELECT id FROM records LIMIT 1'):return 0
    payload={}
    for k,p in files.items():
        if p.exists():payload[k]=json.loads(p.read_text(encoding='utf-8'))
        else:payload[k]={} if k=='users' else []
    backup=data/'legacy_backup';backup.mkdir(exist_ok=True)
    for p in files.values():
        if p.exists():shutil.copy2(p,backup/p.name)
    def legacy_ts(s):
        try:return datetime.strptime(s,'%d.%m.%Y %H:%M').isoformat(timespec='minutes')
        except (ValueError,TypeError) as exc:raise ValueError('Invalid legacy timestamp') from exc
    with connect() as c:
        for uid,u in payload['users'].items():
            c.execute('INSERT INTO users(id,name,status,username,list_access) VALUES(?,?,?,?,?)',(int(uid),u.get('full_name','Неизвестно'),u.get('status','pending'),u.get('username',''),int(bool(u.get('receive_lists')))))
        for s in payload['shifts']:
            try:day=datetime.strptime(s['date'],'%d.%m.%Y').date().isoformat()
            except (ValueError,KeyError) as exc:raise ValueError('Invalid legacy shift date') from exc
            c.execute('INSERT INTO shifts(id,user_id,shop,day,opened,closed,status,pay) VALUES(?,?,?,?,?,?,?,?)',(s['id'],s['user_id'],s['shop'],day,legacy_ts(s.get('opened_at')),legacy_ts(s['closed_at']) if s.get('closed_at') else None,s.get('status','open'),s.get('salary',2300) or 2300))
        for kind,records in (('report',payload['reports']),('list',payload['lists'])):
            for r in records:
                c.execute('INSERT INTO records(kind,user_id,shift_id,shop,category,path,file_id,comment,status,admin_comment,created) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(kind,r['user_id'],r.get('shift_id'),r.get('shop',''),r.get('type',''),r.get('file_path',''),r.get('file_id',''),r.get('comment','') if kind=='report' else r.get('text',''),r.get('status','pending'),r.get('admin_comment',''),legacy_ts(r.get('date'))))
    return 1


def replace_record(old_id,uid,path,file_id,comment,ts,admins=()):
    """Atomically link correction to the original, without crediting salary twice."""
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute("SELECT * FROM records WHERE id=? AND user_id=? AND status='revision'",(old_id,uid)).fetchone()
        if not old:return None
        cur=c.execute("INSERT INTO records(kind,user_id,shift_id,shop,category,path,file_id,comment,status,created,parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(old['kind'],uid,old['shift_id'],old['shop'],old['category'],path,file_id,comment,'pending',ts,old_id))
        c.execute("UPDATE records SET status='superseded' WHERE id=?",(old_id,))
        new_id=cur.lastrowid
        for recipient in set(admins):queue(c,recipient,'CORRECTION:'+str(new_id),path,'',ts)
        return new_id


def submit_list(uid,shop,category,path,body,ts,recipients,chat_id=None,message_id=None):
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        if chat_id is not None and message_id is not None:
            old=c.execute('SELECT record_id FROM incoming_messages WHERE chat_id=? AND message_id=?',(chat_id,message_id)).fetchone()
            if old:return old[0]
        cur=c.execute("INSERT INTO records(kind,user_id,shop,category,path,comment,created) VALUES('list',?,?,?,?,?,?)",(uid,shop,category,path,body,ts))
        if chat_id is not None and message_id is not None:
            c.execute('INSERT INTO incoming_messages(chat_id,message_id,record_id) VALUES(?,?,?)',(chat_id,message_id,cur.lastrowid))
        for recipient in set(recipients):queue(c,recipient,'LIST:'+str(cur.lastrowid),path,'',ts)
        return cur.lastrowid


def claim_payroll_and_queue(key,recipient,body,path,ts):
    """Persist claim and delivery job atomically."""
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        if not c.execute('INSERT OR IGNORE INTO jobs(key,done) VALUES(?,?)',(key,ts)).rowcount:return False
        queue(c,recipient,body,path,'',ts)
        return True

def queue_reminder(slot,employee,employee_text,admins,admin_text,ts):
    """Idempotent reminder scheduling for one shift/hour."""
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        if not c.execute('INSERT OR IGNORE INTO jobs(key,done) VALUES(?,?)',('reminder:'+slot,ts)).rowcount:return False
        queue(c,employee,employee_text,'','',ts)
        for uid in set(admins):queue(c,uid,admin_text,'','',ts)
        return True


def enqueue_admin_event(recipients, event, record_id, path=''):
    with connect() as c:
        for uid in set(recipients):
            queue(c,uid,f'{event}:{record_id}',path,kind=event.lower(),payload=str(record_id))

def failed_deliveries(limit=30):
    return all('SELECT recipient,body,attempts,last_error,created FROM outbox WHERE delivered IS NULL AND attempts>=12 ORDER BY id DESC LIMIT ?', (limit,))

def outbox_stats():
    return one('SELECT COUNT(*) AS total, SUM(CASE WHEN attempts>=12 THEN 1 ELSE 0 END) AS failed FROM outbox WHERE delivered IS NULL')

def reset_failed_outbox(limit=100):
    """Explicit administrative recovery after resolving delivery errors."""
    with connect() as c:
        rows=c.execute('SELECT id FROM outbox WHERE delivered IS NULL AND attempts>=12 ORDER BY id LIMIT ?',(limit,)).fetchall()
        for row in rows:c.execute('UPDATE outbox SET attempts=0,last_error=NULL,created=? WHERE id=?',(datetime.now().isoformat(timespec='seconds'),row[0]))
        return len(rows)

def attachment_health():
    """Report missing files without changing historical records."""
    missing=[]
    for row in all('SELECT id,path FROM records'):
        if not row['path'] or not Path(row['path']).is_file():missing.append(row['id'])
    return missing

def decide_registration(uid,actor,status,ts):
    """Make the registration decision and queue the result in one transaction."""
    if status not in ('approved','rejected'):raise ValueError('Invalid registration decision')
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        changed=c.execute("UPDATE users SET status=? WHERE id=? AND status='pending'",(status,uid)).rowcount
        if not changed:return False
        queue(c,uid,f'REGRESULT:{uid}:{status}:{uid}:{ts}',ts=ts)
        c.execute('INSERT INTO audit(actor,action,detail,created) VALUES(?,?,?,?)',(actor,'registration_'+status,str(uid),ts))
        return True


def claim_outbox_batch(ts,limit=50):
    """Claim due notifications in one transaction; expired leases can be reclaimed."""
    import uuid
    from datetime import datetime, timedelta
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        rows=c.execute("""SELECT o.id FROM outbox o
            WHERE o.delivered IS NULL AND o.attempts<12
            AND (o.lease_until IS NULL OR o.lease_until<?)
            AND (o.attempts=0 OR datetime(substr(COALESCE(o.last_attempt,o.created),1,19),
                '+' || MIN(3600, 15*(1 << MIN(o.attempts,7))) || ' seconds') <= datetime(substr(?,1,19)))
            ORDER BY o.id LIMIT ?""",(ts,ts,limit)).fetchall()
        ids=[r['id'] for r in rows]
        token=uuid.uuid4().hex
        expiry=(datetime.fromisoformat(ts)+timedelta(minutes=30)).isoformat(timespec='seconds')
        for rid in ids:c.execute('UPDATE outbox SET lease_token=?,lease_until=? WHERE id=?',(token,expiry,rid))
        if not ids:return []
        placeholders=','.join('?' for _ in ids)
        return [dict(r) for r in c.execute(f"""SELECT o.*,COALESCE(m.kind,'legacy') AS event_kind
            FROM outbox o LEFT JOIN outbox_meta m ON m.outbox_id=o.id
            WHERE o.id IN ({placeholders}) ORDER BY o.id""",ids)]

def complete_outbox(rid,token,ts):
    return run_update('UPDATE outbox SET delivered=?,attempts=attempts+1,last_error=NULL,lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?',(ts,rid,token))

def fail_outbox(rid,token,error,ts):
    return run_update('UPDATE outbox SET attempts=attempts+1,last_error=?,last_attempt=?,lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?',(error,ts,rid,token))


def update_fsm_field(key, field, value, timestamp):
    """Atomic read-modify-write; avoids lost state/data updates."""
    if field not in ('state', 'data'):
        raise ValueError('Invalid FSM field')
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute('SELECT value FROM fsm WHERE key=?',(key,)).fetchone()
        current=json.loads(row[0]) if row else {'state':None,'data':{}}
        current[field]=value
        current['updated_at']=timestamp
        c.execute('INSERT INTO fsm(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,json.dumps(current,ensure_ascii=False)))

def approve_payroll(period_key, actor, fingerprint, timestamp):
    """Persist a single approved payroll fingerprint; idempotent for identical approvals."""
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        key='payroll_approved:'+period_key
        old=c.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        if old and old[0]!=fingerprint:
            return False
        c.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)',(key,fingerprint))
        c.execute('INSERT INTO audit(actor,action,detail,created) VALUES(?,?,?,?)',(actor,'payroll_approved',period_key+':'+fingerprint,timestamp))
        return True
