"""SQLite schema is managed by app.database.store.init()."""
