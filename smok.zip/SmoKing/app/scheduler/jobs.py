"""Scheduler is currently initialized by app.handlers.legacy.main()."""
