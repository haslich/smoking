from app.services.shift_service import closing_hour
