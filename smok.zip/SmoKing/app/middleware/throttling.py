"""Per-user throttling for message/callback updates."""
import time
from collections import defaultdict, deque
from aiogram import BaseMiddleware

class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, limit=12, window=5):
        self.limit=limit;self.window=window;self.hits=defaultdict(deque)
    async def __call__(self, handler, event, data):
        actor=getattr(event, "from_user", None)
        if actor is None:return await handler(event,data)
        now=time.monotonic()
        if len(self.hits)>=10000:
            self.hits={k:v for k,v in self.hits.items() if v and now-v[-1]<self.window}
        if len(self.hits)>=10000 and actor.id not in self.hits:
            return None
        q=self.hits[actor.id]
        while q and now-q[0]>self.window:q.popleft()
        if len(q)>=self.limit:
            if hasattr(event, "answer"):
                try:
                    if getattr(event,"data",None) is not None:
                        await event.answer("Слишком много запросов. Подождите несколько секунд.",show_alert=True)
                    else:
                        await event.answer("Слишком много запросов. Подождите несколько секунд.")
                except Exception:pass
            return None
        q.append(now)
        if len(self.hits)>10000:
            self.hits={k:v for k,v in self.hits.items() if v and now-v[-1]<self.window}
        return await handler(event,data)
