from app.database import store
def employee_is_approved(user_id:int)->bool:
    return bool(store.one("SELECT 1 FROM users WHERE id=? AND status='approved'",(user_id,)))
