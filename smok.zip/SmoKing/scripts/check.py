"""Run the project's dependency-free local quality checks."""

from __future__ import annotations

import compileall
import os
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
# Executing ``python scripts/check.py`` puts ``scripts`` rather than the
# project root on sys.path.  Tests import the compatibility modules from the
# root, so make that import path explicit before discovery.
sys.path.insert(0, str(ROOT))


def main() -> int:
    print("Compiling Python sources...")
    if not compileall.compile_dir(ROOT, quiet=1):
        return 1

    print("Running unit tests...")
    os.chdir(ROOT)
    suite = unittest.defaultTestLoader.discover(
        start_dir="tests",
        pattern="test_*.py",
    )
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
