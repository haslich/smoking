"""Centralized configuration for new modules."""
import os
from pathlib import Path
from zoneinfo import ZoneInfo
ROOT = Path(__file__).resolve().parent
TIMEZONE = ZoneInfo("Asia/Irkutsk")
PAY_PER_SHIFT = 2300
STORE_CLOSING_HOURS = {"Вихоревка":22,"Тулун 1":22,"Тулун 2":22,"Кирова":23,"Советская":23,"Багульник":23,"Крупская":23,"Энергетик":23}

# Canonical directory for immutable salary export versions.
PAYROLL_EXPORT_DIR = ROOT / "exports" / "payroll"
