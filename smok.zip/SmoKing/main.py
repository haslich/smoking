"""Primary entry point: python main.py."""
import asyncio
from app.handlers.legacy import main
if __name__ == "__main__":
    asyncio.run(main())
