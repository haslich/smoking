"""Backward-compatible module alias: DB overrides affect the real store."""
import sys
from app.database import store as _store
sys.modules[__name__] = _store
