import unittest
from config import ROOT, PAYROLL_EXPORT_DIR
class PayrollPathTests(unittest.TestCase):
    def test_canonical_path(self):
        self.assertEqual(PAYROLL_EXPORT_DIR, ROOT/'exports'/'payroll')
    def test_not_legacy_folder(self):
        self.assertNotEqual(PAYROLL_EXPORT_DIR, ROOT/'salary_reports')
    def test_delivery_does_not_silently_rebuild_missing_export(self):
        # Always name the source encoding: Windows otherwise uses the active
        # ANSI code page (for example cp1251), which cannot decode every UTF-8
        # character used in the bot's messages.
        source=(ROOT/'app/handlers/legacy.py').read_text(encoding='utf-8')
        self.assertIn('Original payroll export missing',source)
        self.assertIn('asyncio.Semaphore(5)',source)
if __name__=='__main__': unittest.main()
