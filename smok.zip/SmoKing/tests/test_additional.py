import tempfile,unittest
from pathlib import Path
import store

class AdditionalTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.original=store.DB
        store.DB=Path(self.tmp.name)/'data.sqlite3';store.init()
    def tearDown(self):
        store.DB=self.original;self.tmp.cleanup()
    def test_outbox_metadata(self):
        store.queue_many([11,12],'hello',kind='message',payload='x')
        rows=store.all('SELECT m.kind,m.payload FROM outbox_meta m')
        self.assertEqual(len(rows),2)
        self.assertTrue(all(r['kind']=='message' for r in rows))
    def test_open_shift_queues_admin_notification(self):
        self.assertTrue(store.open_shift(1,'Вихоревка','2026-11-09','2026-11-09T09:00:00',[99]))
        self.assertEqual(store.one('SELECT body FROM outbox WHERE recipient=99')['body'],'SHIFTOPEN:1')
        self.assertFalse(store.open_shift(1,'Вихоревка','2026-11-09','2026-11-09T09:01:00',[99]))
        self.assertEqual(len(store.all('SELECT * FROM outbox')),1)
    def test_failed_deliveries(self):
        store.queue_many([1],'msg')
        store.run('UPDATE outbox SET attempts=12,last_error=?',('network',))
        self.assertEqual(store.outbox_stats()['failed'],1)
        self.assertEqual(store.failed_deliveries()[0]['last_error'],'network')
if __name__=='__main__':unittest.main()
