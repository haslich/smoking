import tempfile,unittest
from pathlib import Path
from app.database import store

class LeaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.old=store.DB
        store.DB=Path(self.tmp.name)/'test.sqlite3'
        store.init()
    def tearDown(self):
        store.DB=self.old
        self.tmp.cleanup()
    def test_claim_once_then_complete(self):
        store.queue_many([101], 'TEST:unique')
        batch=store.claim_outbox_batch('2026-11-09T10:00:00')
        self.assertEqual(len(batch),1)
        self.assertEqual(store.claim_outbox_batch('2026-11-09T10:01:00'),[])
        self.assertEqual(store.complete_outbox(batch[0]['id'],batch[0]['lease_token'],'2026-11-09T10:01:00'),1)
        self.assertEqual(store.claim_outbox_batch('2026-11-09T10:06:00'),[])
    def test_expired_lease_is_recoverable(self):
        store.queue_many([102],'TEST:recovery')
        first=store.claim_outbox_batch('2026-11-09T10:00:00')
        second=store.claim_outbox_batch('2026-11-09T10:31:00')
        self.assertEqual(first[0]['id'],second[0]['id'])
        self.assertNotEqual(first[0]['lease_token'],second[0]['lease_token'])
        self.assertEqual(store.complete_outbox(first[0]['id'],first[0]['lease_token'],'2026-11-09T10:32:00'),0)
