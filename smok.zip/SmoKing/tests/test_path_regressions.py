"""Regression tests for module path and cleanup startup mistakes."""
import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PathRegressionTests(unittest.TestCase):
    def test_legacy_root_is_project_root(self):
        src=(ROOT/'app/handlers/legacy.py').read_text(encoding='utf-8')
        self.assertIn('ROOT=Path(__file__).resolve().parents[2]',src)

    def test_cleanup_cutoff_defined_before_first_use(self):
        source=(ROOT/'app/handlers/legacy.py').read_text(encoding='utf-8')
        module=ast.parse(source)
        function=next(n for n in module.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='cleanup_temp')
        assigns=[n for n in ast.walk(function) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cutoff' for t in n.targets)]
        self.assertEqual(len(assigns),1)
        self.assertEqual(function.body[0].lineno,assigns[0].lineno)

    def test_database_and_handler_project_roots_match(self):
        dbroot=(ROOT/'app/database/store.py').resolve().parents[2]
        handlerroot=(ROOT/'app/handlers/legacy.py').resolve().parents[2]
        self.assertEqual(dbroot,handlerroot)

if __name__=='__main__':unittest.main()
