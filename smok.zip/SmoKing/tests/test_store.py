import unittest, tempfile, shutil
from pathlib import Path
import store

class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.original=store.DB
        store.DB=Path(self.tmp.name)/'db.sqlite3';store.init()
        store.run("INSERT INTO users(id,name,status) VALUES(1,'Тест Сотрудник','approved')")
    def tearDown(self):
        store.DB=self.original;self.tmp.cleanup()
    def test_one_shift_daily(self):
        self.assertTrue(store.open_shift(1,'Вихоревка','2026-11-09','2026-11-09T08:00'))
        self.assertFalse(store.open_shift(1,'Вихоревка','2026-11-09','2026-11-09T09:00'))
        self.assertFalse(store.open_shift(1,'Кирова','2026-11-10','2026-11-10T08:00'))
    def test_close_once_and_correction(self):
        self.assertTrue(store.open_shift(1,'Вихоревка','2026-11-09','2026-11-09T08:00'))
        shift=store.one('SELECT * FROM shifts WHERE user_id=1')
        rid=store.close_shift(1,'Вихоревка',shift['id'],'/tmp/a.jpg','telegram-id','','2026-11-09T20:00')
        self.assertTrue(rid)
        self.assertIsNone(store.close_shift(1,'Вихоревка',shift['id'],'/tmp/b.jpg','telegram-id','','2026-11-09T20:01'))
        store.run("UPDATE records SET status='revision' WHERE id=?",(rid,))
        new=store.replace_record(rid,1,'/tmp/new.jpg','new-id','','2026-11-09T21:00')
        self.assertTrue(new)
        self.assertIsNone(store.replace_record(rid,1,'/tmp/new2.jpg','new-id','','2026-11-09T21:01'))
        self.assertEqual(store.one('SELECT COUNT(*) n FROM shifts')['n'],1)
        self.assertEqual(store.one('SELECT COUNT(*) n FROM records')['n'],2)
        self.assertEqual(store.one('SELECT status FROM records WHERE id=?',(rid,))['status'],'superseded')
        self.assertEqual(store.one('SELECT parent_id FROM records WHERE id=?',(new,))['parent_id'],rid)
    def test_access_not_owner(self):
        store.open_shift(1,'Кирова','2026-11-09','2026-11-09T08:00')
        sid=store.one('SELECT id FROM shifts')['id']
        rid=store.close_shift(1,'Кирова',sid,'a.jpg','id','','2026-11-09T20:00')
        store.run("UPDATE records SET status='revision' WHERE id=?",(rid,))
        self.assertIsNone(store.replace_record(rid,2,'wrong.jpg','id','','2026-11-09T21:00'))
if __name__=='__main__':unittest.main()
