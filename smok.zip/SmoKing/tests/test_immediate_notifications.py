import asyncio
import unittest

from app.handlers import legacy


class ImmediateNotificationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        legacy.OUTBOX_WAKEUP.clear()

    async def asyncTearDown(self):
        legacy.OUTBOX_WAKEUP.clear()

    async def test_wake_outbox_signals_worker_immediately(self):
        self.assertFalse(legacy.OUTBOX_WAKEUP.is_set())
        legacy.wake_outbox()
        self.assertTrue(legacy.OUTBOX_WAKEUP.is_set())

    async def test_worker_delivers_after_wakeup(self):
        delivered = []
        original = legacy.deliver_outbox

        async def fake_deliver():
            delivered.append(True)
            raise asyncio.CancelledError

        legacy.deliver_outbox = fake_deliver
        legacy.wake_outbox()
        try:
            with self.assertRaises(asyncio.CancelledError):
                await legacy.outbox_worker()
        finally:
            legacy.deliver_outbox = original

        self.assertEqual(delivered, [True])


if __name__ == '__main__':
    unittest.main()
