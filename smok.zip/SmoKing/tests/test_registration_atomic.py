import unittest, tempfile
from pathlib import Path
from unittest.mock import patch
from app.database import store

class RegistrationAtomicTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.patch=patch.object(store,'DB',Path(self.tmp.name)/'test.sqlite3')
        self.patch.start();store.init()
    def tearDown(self):
        self.patch.stop();self.tmp.cleanup()
    def test_registration_and_notification_are_atomic(self):
        self.assertTrue(store.submit_registration(101,'Иван Иванов','ivan',[201,202],'2026-11-09T09:00:00+08:00'))
        self.assertEqual(store.one('SELECT status FROM users WHERE id=101')['status'],'pending')
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],2)
    def test_duplicate_registration_not_queued(self):
        self.assertTrue(store.submit_registration(101,'Иван Иванов','ivan',[201],'2026-11-09T09:00:00+08:00'))
        self.assertFalse(store.submit_registration(101,'Другой Иванов','ivan',[201],'2026-11-09T09:01:00+08:00'))
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],1)
if __name__=='__main__':unittest.main()
