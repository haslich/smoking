import tempfile, unittest
from pathlib import Path
import store

class HardeningTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.original=store.DB
        store.DB=Path(self.tmp.name)/'db.sqlite3';store.init()
        store.run("INSERT INTO users(id,name,status) VALUES(1,'Работник Тестовый','approved')")
    def tearDown(self):store.DB=self.original;self.tmp.cleanup()
    def test_atomic_review(self):
        store.open_shift(1,'Вихоревка','2026-11-09','2026-11-09T09:00')
        sid=store.one('SELECT id FROM shifts')['id']
        rid=store.close_shift(1,'Вихоревка',sid,'/tmp/a.jpg','file','','2026-11-09T20:00',(10,11))
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],2)
        self.assertTrue(store.review(rid,10,'accepted'))
        self.assertFalse(store.review(rid,11,'revision','no'))
        self.assertEqual(store.one('SELECT status FROM records WHERE id=?',(rid,))['status'],'accepted')
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],3)
    def test_list_outbox_transaction(self):
        rid=store.submit_list(1,'Кирова','Доп','/tmp/a.txt','test','2026-11-09T12:00',(10,11))
        self.assertEqual(store.one('SELECT kind FROM records WHERE id=?',(rid,))['kind'],'list')
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],2)
    def test_announcement(self):
        rid=store.queue_announcement(10,'Новость')
        self.assertEqual(rid,1)
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],1)
    def test_duplicate_shift(self):
        self.assertTrue(store.open_shift(1,'Кирова','2026-11-09','2026-11-09T08:00'))
        self.assertFalse(store.open_shift(1,'Кирова','2026-11-09','2026-11-09T08:00'))
if __name__=='__main__':unittest.main()
