import unittest,tempfile
from pathlib import Path
from unittest.mock import patch
import store

class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.dbpatch=patch.object(store,'DB',Path(self.temp.name)/'data.sqlite3')
        self.dbpatch.start();store.init()
    def tearDown(self):
        self.dbpatch.stop();self.temp.cleanup()
    def test_payroll_queue_claim_is_atomic(self):
        self.assertTrue(store.claim_payroll_and_queue('salary:test:1',1,'PAYROLL:2026-10-16:2026-10-31','/tmp/report.xlsx','2026-11-01'))
        self.assertFalse(store.claim_payroll_and_queue('salary:test:1',1,'PAYROLL:2026-10-16:2026-10-31','/tmp/report.xlsx','2026-11-01'))
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],1)
    def test_reminders_deduplicate_same_hour(self):
        self.assertTrue(store.queue_reminder('shift1:0',1,'employee reminder',[2,3],'admin reminder','2026-11-08'))
        self.assertFalse(store.queue_reminder('shift1:0',1,'employee reminder',[2,3],'admin reminder','2026-11-08'))
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],3)
    def test_correction_notifications_atomic(self):
        store.run("INSERT INTO users(id,name,status) VALUES(1,'Test','approved')")
        store.run("INSERT INTO records(kind,user_id,shop,path,created,status) VALUES('list',1,'Вихоревка','/tmp/old.txt','2026-11-08','revision')")
        new=store.replace_record(1,1,'/tmp/new.txt','','new','2026-11-08',[7,8])
        self.assertTrue(new)
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],2)
        self.assertIsNone(store.replace_record(1,1,'/tmp/duplicate.txt','','dup','2026-11-08',[7,8]))
