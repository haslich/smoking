import tempfile
import unittest
from pathlib import Path

import store


class ShopsAndRolesTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.original = store.DB
        store.DB = Path(self.tmp.name) / 'db.sqlite3'
        store.init()
        store.run("INSERT INTO users(id,name,status) VALUES(1,'Сотрудник','approved')")
        store.run("INSERT INTO users(id,name,status) VALUES(2,'Управляющий','approved')")

    def tearDown(self):
        store.DB = self.original
        self.tmp.cleanup()

    def test_shop_settings_define_shift_pay(self):
        store.save_shop('Новый магазин', 8, 21, 2700)
        self.assertTrue(store.open_shift(1, 'Новый магазин', '2026-11-10', '2026-11-10T08:00'))
        shift = store.one('SELECT shop,pay FROM shifts WHERE user_id=1')
        self.assertEqual((shift['shop'], shift['pay']), ('Новый магазин', 2700))

    def test_disabled_shop_can_be_enabled_again(self):
        self.assertEqual(store.set_shop_active('Вихоревка', False), 1)
        self.assertIn('Вихоревка', {x['name'] for x in store.inactive_shops()})
        self.assertNotIn('Вихоревка', {x['name'] for x in store.active_shops()})
        self.assertEqual(store.set_shop_active('Вихоревка', True), 1)
        self.assertIn('Вихоревка', {x['name'] for x in store.active_shops()})

    def test_manager_only_receives_assigned_shop_events(self):
        self.assertTrue(store.assign_manager(2, 'Вихоревка'))
        self.assertIn(2, store.notification_recipients('Вихоревка', {99}))
        self.assertNotIn(2, store.notification_recipients('Кирова', {99}))

    def test_archiving_preserves_history_and_removes_permissions(self):
        store.run('UPDATE users SET list_access=1 WHERE id=2')
        self.assertTrue(store.assign_manager(2, 'Вихоревка'))
        store.open_shift(2, 'Вихоревка', '2026-11-09', '2026-11-09T08:00')
        shift = store.one('SELECT id FROM shifts WHERE user_id=2')
        store.close_shift(2, 'Вихоревка', shift['id'], 'report.jpg', 'file-id', '', '2026-11-09T20:00')
        self.assertEqual(store.archive_employee(2, 99, '2026-11-10T10:00'), 'archived')
        employee = store.one('SELECT status,list_access FROM users WHERE id=2')
        self.assertEqual((employee['status'], employee['list_access']), ('archived', 0))
        self.assertEqual(store.manager_shop_names(2), [])
        self.assertEqual(store.one('SELECT COUNT(*) n FROM shifts WHERE user_id=2')['n'], 1)
        self.assertEqual(store.one('SELECT COUNT(*) n FROM records WHERE user_id=2')['n'], 1)

    def test_employee_with_open_shift_cannot_be_archived(self):
        store.open_shift(2, 'Вихоревка', '2026-11-10', '2026-11-10T08:00')
        self.assertEqual(store.archive_employee(2, 99, '2026-11-10T10:00'), 'open_shift')
        self.assertEqual(store.one('SELECT status FROM users WHERE id=2')['status'], 'approved')

    def test_admin_can_correct_open_shift_shop_and_pay(self):
        store.save_shop('Дорогой магазин', 7, 22, 3100)
        store.open_shift(1, 'Вихоревка', '2026-11-10', '2026-11-10T08:00')
        shift_id = store.one('SELECT id FROM shifts WHERE user_id=1')['id']
        self.assertTrue(store.change_shift_shop(shift_id, 'Дорогой магазин', 99, '2026-11-10T08:05'))
        shift = store.one('SELECT shop,pay FROM shifts WHERE id=?', (shift_id,))
        self.assertEqual((shift['shop'], shift['pay']), ('Дорогой магазин', 3100))


if __name__ == '__main__':
    unittest.main()
