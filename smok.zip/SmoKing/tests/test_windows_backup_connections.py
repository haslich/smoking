import unittest
from pathlib import Path
class TestBackupConnections(unittest.TestCase):
    def test_connections_explicitly_closed(self):
        source=(Path(__file__).resolve().parents[1]/'app/handlers/legacy.py').read_text(encoding='utf-8')
        self.assertIn('with closing(sqlite3.connect(store.DB)) as src, closing(sqlite3.connect(snapshot)) as target:', source)
        self.assertIn('with closing(sqlite3.connect(snapshot)) as db:', source)
        self.assertIn('with closing(sqlite3.connect(restored_db)) as db:', source)
