"""Regression tests for registration decisions and outbox backoff."""
import unittest, tempfile, sqlite3
from pathlib import Path
from unittest.mock import patch
import store

class RegistrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Path(self.tmp.name)/'smoking.sqlite3'
        self.patch=patch.object(store,'DB',self.db)
        self.patch.start()
        store.init()
        store.run("INSERT INTO users(id,name,status) VALUES(101,'Test User','pending')")
    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()
    def test_registration_decision_is_atomic_and_idempotent(self):
        self.assertTrue(store.decide_registration(101,1,'approved','2026-11-09T12:00:00+08:00'))
        self.assertFalse(store.decide_registration(101,2,'rejected','2026-11-09T12:01:00+08:00'))
        self.assertEqual(store.one('SELECT status FROM users WHERE id=101')['status'],'approved')
        self.assertEqual(store.one('SELECT COUNT(*) n FROM outbox')['n'],1)
    def test_last_attempt_column_is_migrated(self):
        cols={r['name'] for r in store.all('PRAGMA table_info(outbox)')}
        self.assertIn('last_attempt',cols)
    def test_bad_status_does_not_mutate(self):
        with self.assertRaises(ValueError):store.decide_registration(101,1,'banned','2026-11-09')
        self.assertEqual(store.one('SELECT status FROM users WHERE id=101')['status'],'pending')

if __name__=='__main__':unittest.main()
