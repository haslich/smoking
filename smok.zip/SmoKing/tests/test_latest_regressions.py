import unittest
from pathlib import Path

SOURCE = (Path(__file__).resolve().parents[1] / 'app' / 'handlers' / 'legacy.py').read_text(encoding='utf-8')

class LatestRegressionTests(unittest.TestCase):
    def test_list_save_holds_storage_lock_through_database_commit(self):
        code = SOURCE.split('async def list_save(', 1)[1].split('@router.callback_query', 1)[0]
        self.assertIn('async with STORAGE_LOCK:', code)
        locked = code.split('async with STORAGE_LOCK:', 1)[1].split('    await state.clear()', 1)[0]
        self.assertIn('rid=store.submit_list(', locked)
    def test_review_buttons_only_for_pending_records(self):
        code = SOURCE.split('async def records_page(', 1)[1].split('@router.callback_query', 1)[0]
        self.assertIn("if x['status']=='pending'", code)
    def test_outbox_plain_message_escapes_html(self):
        self.assertIn('html.unescape(text)[:3800]', SOURCE)

if __name__ == '__main__':unittest.main()
