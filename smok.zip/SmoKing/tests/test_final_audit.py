import tempfile,unittest
from pathlib import Path
import store

class FinalAuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.old=store.DB
        store.DB=Path(self.tmp.name)/'smoking.sqlite3';store.init()
    def tearDown(self):store.DB=self.old;self.tmp.cleanup()
    def test_duplicate_telegram_list_is_idempotent(self):
        args=(17,'Вихоревка','Доп','/tmp/list.txt','milk','2026-11-09T10:00:00',[77],17,104)
        a=store.submit_list(*args);b=store.submit_list(*args)
        self.assertEqual(a,b)
        self.assertEqual(len(store.all("SELECT id FROM records WHERE kind='list'")),1)
        self.assertEqual(len(store.all('SELECT id FROM outbox')),1)
    def test_different_messages_are_separate(self):
        args=(17,'Вихоревка','Доп','/tmp/list.txt','milk','2026-11-09T10:00:00',[77],17)
        self.assertNotEqual(store.submit_list(*args,104),store.submit_list(*args,105))
    def test_failed_notifications_can_be_requeued(self):
        store.queue_many([77],'REPORT:15')
        store.run('UPDATE outbox SET attempts=12,last_error=?',('blocked',))
        self.assertEqual(store.reset_failed_outbox(),1)
        self.assertEqual(store.one('SELECT attempts FROM outbox')['attempts'],0)
    def test_missing_attachment_is_reported(self):
        store.submit_list(17,'Вихоревка','Доп','/not/existing.txt','milk','2026-11-09T10:00:00',[])
        self.assertEqual(len(store.attachment_health()),1)
if __name__=='__main__':unittest.main()
